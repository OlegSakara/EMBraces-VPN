//
//  AppDelegate.swift
//  StartVPN
//
//  Created by Дмитрий Садырев on 12.03.2021.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    private var connectService: ConnectService?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Initialize ConnectService
        connectService = ConnectService()
        print("[AppDelegate] Application finished launching.")

        // Setup initial window with AccountViewController
        let window = UIWindow(frame: UIScreen.main.bounds)
        let nav = UINavigationController()
        let accountVC = AccountViewController() // Initialize AccountViewController
        nav.viewControllers = [accountVC] // Set as the root view controller
        window.rootViewController = nav
        window.makeKeyAndVisible()
        self.window = window
        
        // macOS-specific setup for fixed window size
        #if targetEnvironment(macCatalyst)
        if let windowScene = window.windowScene {
            windowScene.sizeRestrictions?.minimumSize = CGSize(width: 390, height: 844) // iPhone 16 size
            windowScene.sizeRestrictions?.maximumSize = CGSize(width: 390, height: 844)
        }
        #endif

        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        print("[AppDelegate] Scene sessions discarded.")
    }

    func applicationWillResignActive(_ application: UIApplication) {
        print("[AppDelegate] Application will resign active.")
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        print("[AppDelegate] Application entered background. Saving VPN state.")
        saveVPNState()
    }

    func applicationWillTerminate(_ application: UIApplication) {
        print("[AppDelegate] Application is terminating. Disconnecting VPN...")
        connectService?.stopConnecting() // Ensure VPN disconnects only on termination
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        print("[AppDelegate] Application will enter foreground.")
        restoreVPNState()
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        print("[AppDelegate] Application became active.")
    }

    // MARK: - VPN State Management

    private func saveVPNState() {
        guard let connectService = connectService else {
            print("[AppDelegate] ConnectService is not initialized. Skipping VPN state save.")
            return
        }

        let isConnected = UserDefaults.standard.bool(forKey: "isConnected")
        print("[AppDelegate] Saving VPN state for service: \(connectService). State: \(isConnected ? "Connected" : "Disconnected")")
        UserDefaults.standard.set(isConnected, forKey: "isConnected")
    }


    private func restoreVPNState() {
        guard let connectService = connectService else {
            print("[AppDelegate] ConnectService is not initialized. Cannot restore VPN state.")
            return
        }

        let wasConnected = UserDefaults.standard.bool(forKey: "isConnected")
        
        if wasConnected {
            print("[AppDelegate] Restoring VPN state: Attempting to reconnect...")
            connectService.startConnecting() // Start VPN connection without username logic
        } else {
            print("[AppDelegate] No active VPN state to restore.")
        }
    }
}
