import UIKit
import UserNotifications
import ActivityKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?
    var connectService: ConnectService?
    private var backgroundTask: UIBackgroundTaskIdentifier = .invalid

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }

        let window = UIWindow(windowScene: windowScene)
        self.window = window

        let preloaderVC = PreloaderViewController()
        window.rootViewController = preloaderVC
        window.makeKeyAndVisible()

        print("[SceneDelegate] Preloader launched.")

        #if targetEnvironment(macCatalyst)
        if let sizeRestrictions = windowScene.sizeRestrictions {
            let iphone16Size = CGSize(width: 600, height: 840)
            sizeRestrictions.minimumSize = iphone16Size
            sizeRestrictions.maximumSize = iphone16Size
            print("[SceneDelegate] macOS Catalyst: Fixed window size to \(iphone16Size.width)x\(iphone16Size.height).")
        }
        #endif

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleAppTermination),
            name: UIApplication.willTerminateNotification,
            object: nil
        )

        requestNotificationPermission()

        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.loadMainInterface(preloaderVC: preloaderVC)
        }
    }

    private func loadMainInterface(preloaderVC: PreloaderViewController) {
        let hasShownPrivacyPolicy = UserDefaults.standard.bool(forKey: "hasShownPrivacyPolicy")

        if !hasShownPrivacyPolicy {
            showPrivacyPolicy(preloaderVC: preloaderVC)
        } else {
            loadAppMainInterface(preloaderVC: preloaderVC)
        }
    }

    private func showPrivacyPolicy(preloaderVC: PreloaderViewController) {
        let privacyPolicyVC = PrivacyPolicyViewController()
        privacyPolicyVC.modalPresentationStyle = .fullScreen

        preloaderVC.present(privacyPolicyVC, animated: true) {
            UserDefaults.standard.set(true, forKey: "hasShownPrivacyPolicy")
            UserDefaults.standard.synchronize()

            privacyPolicyVC.onAccept = { [weak self] in
                self?.loadAppMainInterface(preloaderVC: preloaderVC)
            }
        }
    }

    private func loadAppMainInterface(preloaderVC: PreloaderViewController) {
        let isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
        let username = UserDefaults.standard.string(forKey: "username")

        let initialViewController: UIViewController
        if isLoggedIn, let username = username, !username.isEmpty {
            let connectVC = ConnectViewController()
            connectVC.username = username
            connectVC.connectService = ConnectService()
            initialViewController = connectVC
            connectService = connectVC.connectService // Подключаем сервис VPN
        } else {
            initialViewController = AccountViewController()
        }

        preloaderVC.stopLoading {
            let navigationController = UINavigationController(rootViewController: initialViewController)
            navigationController.navigationBar.isHidden = true
            self.window?.rootViewController = navigationController
            print("[SceneDelegate] Main view controller set.")
        }
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        print("[SceneDelegate] Scene became active.")
        clearBadgeCount()
    }

    func sceneWillResignActive(_ scene: UIScene) {
        print("[SceneDelegate] Scene will resign active.")
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        print("[SceneDelegate] Scene will enter foreground.")
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        startBackgroundTask()

        // Проверяем, было ли уже отправлено уведомление
        let notificationSent = UserDefaults.standard.bool(forKey: "VPNBackgroundNotificationSent")

        if !notificationSent {
            let serverIP = getServerIP()
            sendLocalNotification(title: "VPN активен в фоне", body: "Вы подключены к серверу: \(serverIP)")
            UserDefaults.standard.set(true, forKey: "VPNBackgroundNotificationSent") // Ставим флаг
            print("[SceneDelegate] Уведомление о VPN в фоне отправлено.")
        } else {
            print("[SceneDelegate] Уведомление о VPN в фоне УЖЕ было отправлено, не дублируем.")
        }

        print("[SceneDelegate] Scene entered background. Keeping VPN active.")
    }


    func sceneDidDisconnect(_ scene: UIScene) {
        print("[SceneDelegate] Scene disconnected. Ensuring VPN cleanup.")
        disconnectVPNIfNeeded()
    }

    // MARK: - Уведомления
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("[SceneDelegate] Уведомления разрешены.")
            } else {
                print("[SceneDelegate] Уведомления запрещены.")
            }
        }
    }

    private func sendVPNConnectedNotification() {
        let serverIP = getServerIP()

        let content = UNMutableNotificationContent()
        content.title = "VPN подключен"
        content.body = "Вы подключены к серверу: \(serverIP)"
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[SceneDelegate] Ошибка отправки уведомления: \(error.localizedDescription)")
            } else {
                print("[SceneDelegate] Уведомление отправлено: \(serverIP)")
            }
        }
    }

    private func clearBadgeCount() {
        UIApplication.shared.applicationIconBadgeNumber = 0
    }

    private func sendLocalNotification(title: String, body: String) {
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("[SceneDelegate] Ошибка отправки уведомления: \(error.localizedDescription)")
            }
        }
    }

    private func getServerIP() -> String {
        guard let connectService = connectService else {
            print("[SceneDelegate] Ошибка: `connectService` отсутствует.")
            return "Неизвестный сервер"
        }
        
        let serverIP = connectService.getVPNServerAddress()
        print("[SceneDelegate] IP-адрес сервера: \(serverIP)")
        return serverIP
    }

    // MARK: - Background Task Management
    private func startBackgroundTask() {
        backgroundTask = UIApplication.shared.beginBackgroundTask(withName: "VPNBackgroundTask") {
            self.endBackgroundTask()
        }
    }

    private func endBackgroundTask() {
        if backgroundTask != .invalid {
            UIApplication.shared.endBackgroundTask(backgroundTask)
            backgroundTask = .invalid
            print("[SceneDelegate] Background task ended.")
        }
    }

    // MARK: - VPN Cleanup
    private func disconnectVPNIfNeeded() {
        if let service = connectService {
            print("[SceneDelegate] Disconnecting VPN to ensure clean termination.")
            service.stopConnecting()
        } else {
            print("[SceneDelegate] No active VPN connection to disconnect.")
        }

        // Сбрасываем флаг, чтобы уведомление могло отправляться снова
        UserDefaults.standard.set(false, forKey: "VPNBackgroundNotificationSent")

        endBackgroundTask()
    }


    // MARK: - App Termination Handling
    @objc private func handleAppTermination() {
        print("[SceneDelegate] App is terminating. Disconnecting VPN.")
        disconnectVPNIfNeeded()
    }
}
