//
//  MacOSInterfaceAdaptation.swift
//  EMBREIS
//
//  Created by Vlad Temmo on 17.01.2025.
//
import UIKit

#if targetEnvironment(macCatalyst)
extension UIView {
    /// Адаптирует размеры для macOS
    func adaptForMacOS() {
        if let window = UIApplication.shared.windows.first {
            self.frame = CGRect(x: 0, y: 0, width: window.bounds.width * 0.8, height: window.bounds.height * 0.8)
        }
    }
}

extension UILabel {
    /// Адаптирует шрифт для macOS
    func adaptFontForMacOS() {
        self.font = UIFont.systemFont(ofSize: 18, weight: .medium)
    }
}

extension UIButton {
    /// Адаптирует кнопки для macOS
    func adaptButtonForMacOS() {
        self.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .bold)
        self.contentEdgeInsets = UIEdgeInsets(top: 10, left: 15, bottom: 10, right: 15)
    }
}
#endif

