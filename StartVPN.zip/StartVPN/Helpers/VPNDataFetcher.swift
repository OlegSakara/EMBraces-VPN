import Foundation

final class VPNDataFetcher {
    
    private init() {}

    /// Асинхронно получить данные конфигурации VPN профиля через API
    /// - Parameters:
    ///   - country: Выбранная страна (Country enum)
    ///   - networkProtocol: Протокол (TCP или UDP)
    ///   - completion: Замыкание с результатом: `Data` или `Error`
    static func getDataFromVPNProfile(country: Country, networkProtocol: NetworkProtocol, completion: @escaping (Result<Data, Error>) -> Void) {
        let apiURL = URL(string: "https://embraces.ru/API/Google/vpn_api_ios.php")!

        // Параметры запроса
        let parameters = [
            "country": country.rawValue,
            "protocol": networkProtocol.rawValue
        ]

        // Создание запроса
        var request = URLRequest(url: apiURL)
        request.httpMethod = "POST"
        request.addValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.addValue("Basic \(Data("admin:yCrtWUuZt0MM".utf8).base64EncodedString())", forHTTPHeaderField: "Authorization")
        request.httpBody = parameters
            .map { "\($0.key)=\($0.value)" }
            .joined(separator: "&")
            .data(using: .utf8)

        print("[VPNDataFetcher] Sending API request for VPN profile...")

        // Выполнение запроса
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("[VPNDataFetcher] ERROR: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }

            guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
                let error = NSError(domain: "VPNDataFetcher", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response from server"])
                print("[VPNDataFetcher] ERROR: Invalid response from server.")
                completion(.failure(error))
                return
            }

            guard let data = data else {
                let error = NSError(domain: "VPNDataFetcher", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data received from server"])
                print("[VPNDataFetcher] ERROR: No data received from server.")
                completion(.failure(error))
                return
            }

            do {
                // Декодирование JSON ответа
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let status = json["status"] as? String,
                   status == "success",
                   let configString = json["config"] as? String {
                    print("[VPNDataFetcher] Configuration fetched successfully.")
                    if let configData = configString.data(using: .utf8) {
                        completion(.success(configData))
                    } else {
                        let error = NSError(domain: "VPNDataFetcher", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to encode configuration string"])
                        completion(.failure(error))
                    }
                } else {
                    let error = NSError(domain: "VPNDataFetcher", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid response format"])
                    print("[VPNDataFetcher] ERROR: Invalid response format.")
                    completion(.failure(error))
                }
            } catch {
                print("[VPNDataFetcher] ERROR: Failed to decode response: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }

        task.resume()
    }
}
