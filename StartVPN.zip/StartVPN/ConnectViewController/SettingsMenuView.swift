import SwiftUI

struct SettingsMenuView: View {
    var onClose: () -> Void
    @Binding var isEnergySavingOn: Bool
    @Binding var isRTL: Bool

    var body: some View {
        ZStack(alignment: .bottom) {
            // Затемнённый фон
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                .onTapGesture {
                    withAnimation {
                        onClose()
                    }
                }

            // Прямоугольное меню без скруглений
            VStack {
                // Заголовок меню
                HStack {
                    Text("Настройки")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding(.leading, 16)

                    Spacer()

                    Button(action: {
                        withAnimation {
                            onClose()
                        }
                    }) {
                        Text("X")
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .padding(.trailing, 16)
                }
                .padding(.top, 16)

                // Содержимое меню
                VStack(alignment: .leading, spacing: 12) {
                    MenuItem(icon: "bolt.fill", title: "Energy Saving", isSwitchOn: $isEnergySavingOn)
                    Divider().frame(height: 1).background(Color.gray)

                    MenuItem(icon: "textformat", title: "RTL Display", isSwitchOn: $isRTL)
                    Divider().frame(height: 1).background(Color.gray)

                    Link(destination: URL(string: "https://embraces.ru/privacy")!) {
                        HStack {
                            Image(systemName: "eye.fill")
                                .foregroundColor(.orange)
                            Text("Privacy Policy")
                                .foregroundColor(.white)
                            Spacer()
                        }
                    }
                    Divider().frame(height: 1).background(Color.gray)
                }
                .padding(.horizontal, 24)
                .padding(.top, 16)
                .padding(.bottom, 16) // Внутренний отступ снизу
            }
            .frame(maxWidth: .infinity)
            .frame(height: 300) // Высота меню
            .background(
                Rectangle() // Прямоугольник вместо RoundedRectangle
                    .fill(Color("BackgroundColor")) // Чистый фон
            )
            .ignoresSafeArea(edges: .bottom) // Плотно прилегает к низу экрана
        }
    }
}
