import UIKit

class LanguesViewController_login: UIViewController {
    var languageManager: LanguageManager! // Менеджер языков

    private let languages: [String] = ["en", "zh", "ru", "ar"] // Добавляем арабский язык
    private var switches: [UISwitch] = [] // Массив переключателей
    private let titleLabel = UILabel() // Заголовок

    override func viewDidLoad() {
        super.viewDidLoad()
        assert(languageManager != nil, "LanguageManager должен быть инициализирован!") // Проверяем LanguageManager

        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        setupNavigationBar()
        setupSettingsContent()
        updateTitleTranslation() // Обновляем заголовок
        navigationController?.interactivePopGestureRecognizer?.delegate = self

    }

    private func setupNavigationBar() {
        navigationItem.hidesBackButton = true

        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

        let backButtonContainer = UIView()
        backButtonContainer.translatesAutoresizingMaskIntoConstraints = false
        backButtonContainer.addSubview(backButton)
        backButtonContainer.isUserInteractionEnabled = true
        backButtonContainer.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(backButtonTapped)))

        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        navigationContainer.addSubview(backButtonContainer)
        navigationContainer.addSubview(titleLabel)

        let topPadding: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 50 : 75 // Уменьшенный отступ для iPad

        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.topAnchor, constant: topPadding),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60),

            backButtonContainer.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor),
            backButtonContainer.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButtonContainer.widthAnchor.constraint(equalToConstant: 60),
            backButtonContainer.heightAnchor.constraint(equalToConstant: 60),

            backButton.centerYAnchor.constraint(equalTo: backButtonContainer.centerYAnchor),
            backButton.leadingAnchor.constraint(equalTo: backButtonContainer.leadingAnchor, constant: 8),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor)
        ])
    }


    private func setupSettingsContent() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 12
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        let globeImage = UIImage(systemName: "globe")

        let englishRow = createSettingsRow(iconImage: globeImage, title: "English", languageCode: "en")
        let chineseRow = createSettingsRow(iconImage: globeImage, title: "中文", languageCode: "zh")
        let russianRow = createSettingsRow(iconImage: globeImage, title: "Русский", languageCode: "ru")
        let arabicRow = createSettingsRow(iconImage: globeImage, title: "العربية", languageCode: "ar") // Добавляем арабский язык

        stackView.addArrangedSubview(englishRow)
        stackView.addArrangedSubview(chineseRow)
        stackView.addArrangedSubview(russianRow)
        stackView.addArrangedSubview(arabicRow) // Добавляем переключатель для арабского языка

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func createSettingsRow(iconImage: UIImage?, title: String, languageCode: String) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false

        let iconImageView = UIImageView(image: iconImage)
        iconImageView.tintColor = .orange
        iconImageView.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        let toggleSwitch = UISwitch()
        toggleSwitch.isOn = (languageManager.currentLanguage == languageCode)
        toggleSwitch.onTintColor = .orange
        toggleSwitch.translatesAutoresizingMaskIntoConstraints = false
        toggleSwitch.tag = switches.count
        toggleSwitch.addTarget(self, action: #selector(switchToggled(_:)), for: .valueChanged)
        switches.append(toggleSwitch)

        container.addSubview(iconImageView)
        container.addSubview(titleLabel)
        container.addSubview(toggleSwitch)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),

            toggleSwitch.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            toggleSwitch.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            container.heightAnchor.constraint(equalToConstant: 50)
        ])

        return container
    }

    @objc private func switchToggled(_ sender: UISwitch) {
        let selectedLanguage = languages[sender.tag]
        languageManager?.setLanguage(selectedLanguage)

        for (index, toggle) in switches.enumerated() {
            toggle.isOn = (index == sender.tag)
        }

        updateTitleTranslation()

        DispatchQueue.main.async {
            NotificationCenter.default.post(name: .languageChanged, object: nil)
        }
    }

    private func updateTitleTranslation() {
        let translations: [String: String] = [
            "en": "Languages",
            "zh": "语言",
            "ru": "Языки",
            "ar": "اللغات"
        ]
        titleLabel.text = translations[languageManager.currentLanguage] ?? "Languages"
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
}
extension LanguesViewController_login: UIGestureRecognizerDelegate {}
