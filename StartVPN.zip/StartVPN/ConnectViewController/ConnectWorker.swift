import UIKit
import NetworkExtension
import Network
import Security

class ConnectService {
    
    weak var interactor: ConnectInteractor?
    var networkProtocol: NetworkProtocol = .TCP
    var selectedCountry: Country = .random {
        didSet {
            if selectedCountry != oldValue && oldValue != .random {
                stopConnecting()
            }
        }
    }
    
    private var timer = Timer()
    private var connectingStatus: NEVPNStatus = .disconnected
    private var manager: NETunnelProviderManager?
    private var managerLoaded = false
    private let stopQueue = DispatchQueue(label: "ConnectService.stopQueue", attributes: .concurrent)
    private var isStopping = false
    private var selectedCountryIndex: Int {
        return Country.allCases.firstIndex(where: { $0 == selectedCountry }) ?? 0
    }
    
    private var username: String? {
        didSet {
            print("[ConnectService] Username updated to: \(username ?? "Unknown")")
            UserDefaults.standard.set(username, forKey: "username")
        }
    }
    
    // MARK: - Initialization
    init() {
        username = UserDefaults.standard.string(forKey: "username")
        if retrievePasswordFromKeychain() == nil {
            let newPassword = generateRandomPassword(length: 16)
            savePasswordToKeychain(password: newPassword)
        }
        
        NotificationCenter.default.addObserver(forName: NSNotification.Name.NEVPNStatusDidChange, object: nil, queue: nil) { [weak self] notification in
            guard let connection = notification.object as? NEVPNConnection else { return }
            self?.checkNEStatus(status: connection.status)
        }
        loadManager()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        print("[DEINIT] \(String(describing: type(of: self))) deinitialized, observers removed.")
    }
    
    // MARK: - Username Management
    func updateUsername(newUsername: String) {
        guard !newUsername.isEmpty else {
            print("[ConnectService] Cannot update to an empty username.")
            return
        }
        username = newUsername
        print("[ConnectService] Username dynamically updated to: \(newUsername)")
    }
    
    func getUsername() -> String? {
        return username
    }
    
    private func loadManager() {
        guard !managerLoaded else { return }
        print("[VPN] Loading manager from preferences...")
        
        NETunnelProviderManager.loadAllFromPreferences { [weak self] managers, error in
            if let error = error {
                print("[VPN] Failed to load managers during initialization: \(error.localizedDescription)")
                return
            }
            self?.manager = managers?.first ?? NETunnelProviderManager()
            self?.managerLoaded = true
            print("[VPN] Manager initialized successfully.")
        }
    }
    
    // MARK: - Status Handling
    private func checkNEStatus(status: NEVPNStatus) {
        connectingStatus = status
        
        switch status {
        case .invalid:
            print("[VPN] Status: Invalid")
        case .disconnected:
            print("[VPN] Status: Disconnected")
            interactor?.makeRequest(request: .statusChangedToDisconnected)
            interactor?.makeRequest(request: .showMap(index: nil))
        case .connecting:
            print("[VPN] Status: Connecting")
            interactor?.makeRequest(request: .statusChangedToConnecting)
        case .connected:
            print("[VPN] Status: Connected")
            interactor?.makeRequest(request: .statusChangedToConnected)
            interactor?.makeRequest(request: .showMap(index: selectedCountryIndex))
            startTimer()
        case .reasserting:
            print("[VPN] Status: Reasserting")
        case .disconnecting:
            print("[VPN] Status: Disconnecting")
        @unknown default:
            print("[VPN] Status: Unknown")
        }
    }
    
    // MARK: - Timer
    private func startTimer() {
        timer.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerUpdate), userInfo: Date(), repeats: true)
    }
    
    @objc private func timerUpdate() {
        guard let startDate = timer.userInfo as? Date else { return }
        let elapsed = -startDate.timeIntervalSinceNow
        let hours = Int(elapsed / 3600)
        let minutes = Int((elapsed.truncatingRemainder(dividingBy: 3600)) / 60)
        let seconds = Int(elapsed.truncatingRemainder(dividingBy: 60))
        
        let formattedTime = hours > 0 ? String(format: "%02d:%02d:%02d", hours, minutes, seconds) : String(format: "%02d:%02d", minutes, seconds)
        interactor?.makeRequest(request: .updateTimer(timer: formattedTime))
        getTrafficStats()
    }
    
    private func getTrafficStats() {
        guard let session = manager?.connection as? NETunnelProviderSession else { return }
        do {
            try session.sendProviderMessage("SOME_STATIC_KEY".data(using: .utf8)!) { [weak self] data in
                guard
                    let data = data,
                    let stats = try? NSKeyedUnarchiver.unarchivedObject(ofClasses: [NSDictionary.self, NSString.self, NSNumber.self], from: data) as? [String: Int64]
                else { return }
                
                let bytesOut = stats["bytesOut"] ?? 0
                let bytesIn = stats["bytesIn"] ?? 0
                self?.interactor?.makeRequest(request: .updateTrafficStats(upload: bytesOut, download: bytesIn))
            }
        } catch {
            print("[VPN] Failed to get traffic stats: \(error)")
        }
    }
    
    // MARK: - VPN Control
    func stopConnecting() {
        stopQueue.sync(flags: .barrier) {
            guard !isStopping else {
                print("[VPN] Stop is already in progress. Skipping...")
                return
            }
            isStopping = true
        }
        
        print("[VPN] Stopping VPN...")
        
        guard managerLoaded else {
            print("[VPN] Manager is not loaded yet. Cannot stop VPN.")
            resetStoppingFlag()
            return
        }
        
        guard let manager = manager else {
            print("[VPN] Manager is nil.")
            resetStoppingFlag()
            return
        }

        if manager.connection.status == .connected || manager.connection.status == .connecting {
            manager.connection.stopVPNTunnel()
            print("[VPN] VPN tunnel stopped.")
        } else {
            print("[VPN] VPN is not active, skipping stop.")
        }

        resetManagerState()
        resetStoppingFlag()
    }

    private func resetManagerState() {
        print("[VPN] Resetting manager state...")
        manager = nil
        managerLoaded = false
        loadManager()
    }

    func startConnecting() {
        guard managerLoaded else {
            print("[VPN] Manager is not loaded yet. Cannot start VPN.")
            return
        }

        if let storedUsername = UserDefaults.standard.string(forKey: "username") {
            username = storedUsername
            print("[VPN] Username reset to: \(username ?? "Unknown")")
        } else {
            print("[VPN] Username is not set in UserDefaults. Aborting connection.")
            interactor?.makeRequest(request: .showError(title: "Username Missing", message: "Please log in again."))
            return
        }

        guard let username = self.username, !username.isEmpty else {
            print("[VPN] Missing or empty username.")
            interactor?.makeRequest(request: .showError(title: "Missing Username", message: "Please log in again."))
            return
        }

        guard let password = retrievePasswordFromKeychain() else {
            print("[VPN] Missing or empty password.")
            interactor?.makeRequest(request: .showPasswordAlert)
            return
        }

        print("[VPN] Starting connection with username: \(username)")
        configureVPN { [weak self] error in
            if let error = error {
                print("[VPN] Configuration failed: \(error.localizedDescription)")
                self?.interactor?.makeRequest(request: .showError(title: "Configuration Error", message: error.localizedDescription))
                return
            }

            do {
                try self?.manager?.connection.startVPNTunnel(options: ["username": username as NSString, "password": password as NSString])
                print("[VPN] VPN started successfully with username: \(username)")
            } catch {
                print("[VPN] Failed to start tunnel: \(error.localizedDescription)")
                self?.interactor?.makeRequest(request: .showPasswordAlert)
            }
        }
    }

    // MARK: - Configuration
    private func configureVPN(callback: @escaping (Error?) -> Void) {
        if selectedCountry == .random {
            selectedCountry = Country[Int.random(in: 1..<Country.allCases.count), default: .USA]
            interactor?.makeRequest(request: .didSelectCountry(country: selectedCountry))
        }
        
        VPNDataFetcher.getDataFromVPNProfile(country: selectedCountry, networkProtocol: networkProtocol) { [weak self] result in
            guard let self = self else {
                callback(NSError(domain: "ConnectService", code: -1, userInfo: [NSLocalizedDescriptionKey: "Self deallocated during VPN configuration"]))
                return
            }
            
            switch result {
            case .success(let configurationContent):
                print("[ConnectService] VPN configuration successfully fetched.")
                self.manager?.loadFromPreferences { error in
                    if let error = error {
                        print("[ConnectService] Error loading manager preferences: \(error.localizedDescription)")
                        callback(error)
                        return
                    }
                    
                    print("[ConnectService] Configuring NETunnelProviderProtocol.")
                    let tunnelProtocol = NETunnelProviderProtocol()
                    tunnelProtocol.serverAddress = "89.110.86.151"
                    tunnelProtocol.providerBundleIdentifier = "com.test.StartVPN.tunnel"
                    tunnelProtocol.providerConfiguration = [
                        "configuration": configurationContent,
                        "data-ciphers": "AES-128-CBC"
                    ]
                    tunnelProtocol.disconnectOnSleep = false
                    
                    self.manager?.protocolConfiguration = tunnelProtocol
                    self.manager?.localizedDescription = "EMBREIS VPN"
                    self.manager?.isEnabled = true
                    
                    self.manager?.saveToPreferences { error in
                        if let error = error {
                            print("[ConnectService] Error saving manager preferences: \(error.localizedDescription)")
                        } else {
                            print("[ConnectService] VPN configuration saved successfully.")
                        }
                        callback(error)
                    }
                }
            case .failure(let error):
                print("[ConnectService] Failed to fetch VPN configuration: \(error.localizedDescription)")
                callback(error)
            }
        }
    }
    
    public func getVPNServerAddress() -> String {
        guard let manager = manager, manager.isEnabled else {
            print("[VPN] Ошибка: `manager` не загружен или отключен.")
            return "Неизвестный сервер"
        }

        guard let tunnelProtocol = manager.protocolConfiguration as? NETunnelProviderProtocol,
              let serverAddress = tunnelProtocol.serverAddress, !serverAddress.isEmpty else {
            print("[VPN] Ошибка: `serverAddress` пуст или отсутствует.")
            return "Неизвестный сервер"
        }

        print("[VPN] IP-адрес сервера: \(serverAddress)")
        return serverAddress
    }


    // MARK: - Password Management
    private func generateRandomPassword(length: Int) -> String {
        let characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?"
        return String((0..<length).compactMap { _ in characters.randomElement() })
    }
    
    private func savePasswordToKeychain(password: String) {
        guard let passwordData = password.data(using: .utf8) else { return }
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "VPNPassword",
            kSecValueData as String: passwordData
        ]
        SecItemDelete(query as CFDictionary) // Удаление старого пароля
        SecItemAdd(query as CFDictionary, nil)
    }
    
    private func retrievePasswordFromKeychain() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: "VPNPassword",
            kSecReturnData as String: true
        ]
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func resetStoppingFlag() {
        stopQueue.sync(flags: .barrier) {
            isStopping = false
        }
    }
}
