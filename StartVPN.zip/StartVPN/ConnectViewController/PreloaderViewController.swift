import UIKit

class PreloaderViewController: UIViewController {

    private let titleLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Установка фона
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black

        // Настройка заголовка
        setupTitleLabel()
    }

    private func setupTitleLabel() {
        // Создание лейбла "EMBRACES VPN"
        let text = "EMBRACES VPN"

        // Определяем размеры шрифта в зависимости от платформы
        let fontSize: CGFloat
        #if targetEnvironment(macCatalyst)
        fontSize = 48 // Увеличенный шрифт для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            fontSize = 42 // Увеличенный шрифт для iPad
        } else {
            fontSize = 32 // Обычный шрифт для iPhone
        }
        #endif

        // Создаем атрибуты для текста
        let attributedText = NSMutableAttributedString(
            string: text,
            attributes: [
                .font: UIFont.systemFont(ofSize: fontSize, weight: .bold),
                .foregroundColor: UIColor.white
            ]
        )

        if let embracesRange = text.range(of: "EMBRACES") {
            let nsRange = NSRange(embracesRange, in: text)
            attributedText.addAttributes([
                .foregroundColor: UIColor(named: "EMBRACES") ?? .orange // Цвет из Assets
            ], range: nsRange)
        }

        titleLabel.attributedText = attributedText
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(titleLabel)

        // Установка ограничений для размещения
        NSLayoutConstraint.activate([
            titleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? -20 : 0) // Смещение для iPad
        ])
    }

    /// Завершение загрузки с плавным исчезновением экрана
    func stopLoading(completion: @escaping () -> Void) {
        UIView.animate(withDuration: 0.3, animations: {
            self.view.alpha = 0
        }, completion: { _ in
            completion()
        })
    }
}
