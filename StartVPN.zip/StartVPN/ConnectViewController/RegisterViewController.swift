import UIKit

class RegisterViewController: UIViewController, UITextFieldDelegate {
    private let mandatoryLabel = UILabel()
    private let continueButton = UIButton(type: .system)
    private let inputField = UITextField()
    private let messageLabel = UILabel()
    private var waitingTimer: Timer?
    private var dotCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        setupNavigationBar()
        setupUI()
        setupDismissKeyboardGesture()
        navigationController?.interactivePopGestureRecognizer?.delegate = self

    }

    private func setupNavigationBar() {
        // Убираем кнопку "назад"
        navigationItem.hidesBackButton = true

        // Контейнер для навигационного бара
        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        // Кнопка "назад"
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal) // Иконка стрелки
        backButton.tintColor = .white // Белый цвет
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        navigationContainer.addSubview(backButton)

        // Заголовок
        let titleLabel = UILabel()
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold) // Шрифт
        titleLabel.textColor = .white // Цвет текста
        titleLabel.textAlignment = .center // Выравнивание по центру
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        // Добавляем перевод для заголовка
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
        let titleTranslations = [
            "en": "Register",     // Английский
            "zh": "注册",          // Китайский
            "ru": "Регистрация"   // Русский
        ]
        titleLabel.text = titleTranslations[selectedLanguage] ?? "Register" // Выбираем перевод

        navigationContainer.addSubview(titleLabel)

        // Определяем отступ для iPad и iPhone
        let topPadding: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 50 : 75 // Уменьшаем отступ для iPad

        // Устанавливаем ограничения (Auto Layout)
        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.topAnchor, constant: topPadding),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60),

            backButton.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor, constant: 8),
            backButton.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor)
        ])
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }

    private func setupUI() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        stackView.addArrangedSubview(createInputFieldContainer())
        setupContinueButton()
        stackView.addArrangedSubview(continueButton)
        setupMessageLabel()
        stackView.addArrangedSubview(messageLabel)

        NSLayoutConstraint.activate([
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func createInputFieldContainer() -> UIView {
        let container = UIView()
        container.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        container.layer.cornerRadius = 8
        container.layer.borderWidth = 1
        container.layer.borderColor = (UIColor(named: "AccentOrange") ?? .orange).cgColor
        container.translatesAutoresizingMaskIntoConstraints = false

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(activateInputField))
        container.addGestureRecognizer(tapGesture)

        inputField.font = UIFont.systemFont(ofSize: 14)
        inputField.textColor = .white
        inputField.delegate = self
        inputField.translatesAutoresizingMaskIntoConstraints = false

        // Установка белого цвета для плейсхолдера
        let placeholderText = NSLocalizedString("Enter Username", comment: "Placeholder for Username")
        inputField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [.foregroundColor: UIColor.white.withAlphaComponent(0.6)]
        )
        container.addSubview(inputField)

        mandatoryLabel.font = UIFont.systemFont(ofSize: 12)
        mandatoryLabel.textColor = .white
        mandatoryLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(mandatoryLabel)

        updateInputFieldTranslations()

        NSLayoutConstraint.activate([
            container.heightAnchor.constraint(equalToConstant: 60),

            inputField.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            inputField.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            inputField.trailingAnchor.constraint(lessThanOrEqualTo: mandatoryLabel.leadingAnchor, constant: -8),

            mandatoryLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            mandatoryLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor)
        ])

        return container
    }

    private func updateInputFieldTranslations() {
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
        
        // Обновление текста и цвета плейсхолдера
        let placeholderText = [
            "en": "Enter Username",
            "zh": "输入用户名",
            "ru": "Введите имя пользователя",
            "ar": "أدخل اسم المستخدم"
        ][selectedLanguage] ?? "Username"

        inputField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [.foregroundColor: UIColor.white.withAlphaComponent(0.6)]
        )

        mandatoryLabel.text = [
            "en": "required",
            "zh": "必填",
            "ru": "обязательно",
            "ar": "مطلوب"
        ][selectedLanguage] ?? "required"
    }


    @objc private func activateInputField() {
        inputField.becomeFirstResponder()
    }

    private func setupContinueButton() {
        // Получаем выбранный язык из UserDefaults
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Словарь переводов для кнопки
        let buttonTranslations = [
            "en": "Register",
            "zh": "注册",
            "ru": "Регистрация",
            "ar": "تسجيل"
        ]

        // Устанавливаем текст кнопки на основе языка
        let buttonTitle = buttonTranslations[selectedLanguage] ?? "Register"
        continueButton.setTitle(buttonTitle, for: .normal)

        // Настраиваем внешний вид кнопки
        continueButton.setTitleColor(.lightGray, for: .normal)
        continueButton.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        continueButton.layer.cornerRadius = 12
        continueButton.layer.borderWidth = 1
        continueButton.layer.borderColor = UIColor.lightGray.cgColor
        continueButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        continueButton.translatesAutoresizingMaskIntoConstraints = false
        continueButton.addTarget(self, action: #selector(continueButtonTapped), for: .touchUpInside)
        continueButton.isEnabled = false

        // Устанавливаем высоту кнопки
        NSLayoutConstraint.activate([
            continueButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }

    private func setupMessageLabel() {
        messageLabel.textColor = .red
        messageLabel.font = UIFont.systemFont(ofSize: 16)
        messageLabel.textAlignment = .center
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
    }

    private func setupDismissKeyboardGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }

    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        guard let currentText = textField.text else { return true }
        let updatedText = (currentText as NSString).replacingCharacters(in: range, with: string).trimmingCharacters(in: .whitespaces)

        let isInputValid = updatedText.count >= 3
        continueButton.isEnabled = isInputValid
        continueButton.setTitleColor(isInputValid ? .white : .lightGray, for: .normal)
        continueButton.layer.borderColor = isInputValid ? UIColor.systemOrange.cgColor : UIColor.lightGray.cgColor
        continueButton.backgroundColor = isInputValid ? UIColor.systemOrange : UIColor.lightGray.withAlphaComponent(0.2)

        return true
    }

    @objc private func continueButtonTapped() {
        // Убираем клавиатуру
        dismissKeyboard()

        guard let username = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !username.isEmpty else {
            return
        }

        // Отключаем кнопку, чтобы предотвратить повторное нажатие
        continueButton.isEnabled = false

        // Запускаем анимацию "Please wait..."
        startWaitingAnimation()

        // Задержка на 3 секунды перед регистрацией
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.registerUser(username: username)
            self.stopWaitingAnimation() // Останавливаем анимацию
        }
    }
    
    private func startWaitingAnimation() {
        // Получаем текущий язык из UserDefaults
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Перевод для "Please wait"
        let translations = [
            "en": "Please wait",
            "zh": "请稍等",
            "ru": "Пожалуйста, подождите",
            "ar": "يرجى الانتظار"
        ]
        let waitingText = translations[selectedLanguage] ?? "Please wait"

        // Устанавливаем начальное сообщение с белым цветом
        messageLabel.text = waitingText
        messageLabel.textColor = .white // Цвет текста — белый
        messageLabel.font = UIFont.systemFont(ofSize: 18) // Размер шрифта

        // Сбрасываем счетчик точек
        dotCount = 0

        // Запускаем таймер для обновления сообщения каждые 0.5 секунды
        waitingTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            
            // Увеличиваем количество точек и обновляем текст
            self.dotCount = (self.dotCount + 1) % 4 // Цикл от 0 до 3
            let dots = String(repeating: ".", count: self.dotCount)
            self.messageLabel.text = waitingText + dots
        }
    }


    private func stopWaitingAnimation() {
        // Останавливаем таймер
        waitingTimer?.invalidate()
        waitingTimer = nil

        // Сбрасываем сообщение
        messageLabel.text = ""
    }

    private func registerUser(username: String) {
        guard let url = URL(string: "https://embraces.ru/API/Google/create_usr.php") else {
            showMessage(translate("Invalid URL"), isError: true)
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // Basic Authentication
        let loginString = "yCrtWUuZt0MM:yCrtWUuZt0MM" 
        guard let loginData = loginString.data(using: .utf8) else {
            showMessage(translate("Encoding error"), isError: true)
            return
        }
        let base64LoginString = loginData.base64EncodedString()
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")

        // Тело запроса
        let requestBody: [String: Any] = ["action": "register", "name": username]
        guard let httpBody = try? JSONSerialization.data(withJSONObject: requestBody) else {
            showMessage(translate("Error creating request body"), isError: true)
            return
        }
        request.httpBody = httpBody

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    let errorMessage = String(format: self.translate("Network error: %@"), error.localizedDescription)
                    self.showMessage(errorMessage, isError: true)
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.showMessage(self.translate("No response from server"), isError: true)
                }
                return
            }

            // Проверяем HTTP-статус
            guard (200...299).contains(httpResponse.statusCode) else {
                DispatchQueue.main.async {
                    let statusCodeMessage = String(format: self.translate("Server error: HTTP %d"), httpResponse.statusCode)
                    self.showMessage(statusCodeMessage, isError: true)
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.showMessage(self.translate("No response data"), isError: true)
                }
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let status = json["status"] as? String {
                    if status == "success" {
                        DispatchQueue.main.async {
                            self.saveUserAndNavigate(username: username)
                        }
                    } else {
                        let errorMessage = json["message"] as? String ?? self.translate("Unknown error")
                        DispatchQueue.main.async {
                            self.showMessage(self.translate(errorMessage), isError: true)
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        self.showMessage(self.translate("Invalid response format"), isError: true)
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    let errorMessage = String(format: self.translate("Error processing data: %@"), error.localizedDescription)
                    self.showMessage(errorMessage, isError: true)
                }
            }
        }.resume()
    }


    private func translate(_ text: String, with arguments: [CVarArg] = []) -> String {
        // Получаем текущий язык
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Словарь переводов
        let translations: [String: [String: String]] = [
            "Invalid URL": [
                "en": "Invalid URL",
                "zh": "无效的URL",
                "ru": "Неверный URL",
                "ar": "عنوان URL غير صالح"
            ],
            "Network error: %@": [
                "en": "Network error: %@",
                "zh": "网络错误: %@",
                "ru": "Сетевая ошибка: %@",
                "ar": "خطأ في الشبكة: %@"
            ],
            "No response data": [
                "en": "No response data",
                "zh": "没有响应数据",
                "ru": "Нет данных ответа",
                "ar": "لا توجد بيانات استجابة"
            ],
            "Unknown error": [
                "en": "Unknown error",
                "zh": "未知错误",
                "ru": "Неизвестная ошибка",
                "ar": "خطأ غير معروف"
            ],
            "Invalid response format": [
                "en": "Invalid response format",
                "zh": "响应格式无效",
                "ru": "Неверный формат ответа",
                "ar": "تنسيق استجابة غير صالح"
            ],
            "Error processing data: %@": [
                "en": "Error processing data: %@",
                "zh": "处理数据时出错: %@",
                "ru": "Ошибка обработки данных: %@",
                "ar": "خطأ في معالجة البيانات: %@"
            ],
            "User already exists": [
                "en": "User already exists",
                "zh": "用户已存在",
                "ru": "Пользователь уже существует",
                "ar": "المستخدم موجود بالفعل"
            ]
        ]


        // Получаем перевод строки
        let template = translations[text]?[selectedLanguage] ?? text

        // Если есть аргументы, подставляем их в шаблон
        return String(format: template, arguments: arguments)
    }

    private func localizedMessage(forKey key: String) -> String {
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Словарь переводов для сообщений
        let translations: [String: [String: String]] = [
            "userAlreadyExists": [
                "en": "User already exists",
                "zh": "用户已存在",
                "ru": "Пользователь уже существует",
                "ar": "المستخدم موجود بالفعل"
            ],
            
        ]

        // Возвращаем перевод на основе ключа и языка
        return translations[key]?[selectedLanguage] ?? translations[key]?["en"] ?? "Message not found"
    }
    
    private func saveUserAndNavigate(username: String) {
        // Сохраняем имя пользователя и статус входа
        UserDefaults.standard.set(username, forKey: "username")
        UserDefaults.standard.set(true, forKey: "isLoggedIn") // Устанавливаем статус входа
        UserDefaults.standard.synchronize()

        // Переход на ConnectViewController
        navigateToConnectViewController(username: username)
    }

    
    private func navigateToConnectViewController(username: String) {
        // Сохраняем имя пользователя
        UserDefaults.standard.set(username, forKey: "username")

        // Создаём экземпляр ConnectViewController
        let connectVC = ConnectViewController()
        connectVC.username = username // Передаём имя пользователя

        // Устанавливаем полноэкранное отображение
        connectVC.modalPresentationStyle = .fullScreen

        // Переходим на ConnectViewController
        navigationController?.pushViewController(connectVC, animated: true)

        // Запускаем подключение
        ConnectService().startConnecting()
    }
    
    private func showMessage(_ message: String, isError: Bool = false) {
        DispatchQueue.main.async {
            self.messageLabel.text = message
            self.messageLabel.textColor = isError ? .red : .white // Устанавливаем цвет текста в зависимости от типа сообщения
            self.messageLabel.font = UIFont.systemFont(ofSize: 16) // Оставляем фиксированный размер шрифта
        }
    }

}
extension RegisterViewController: UIGestureRecognizerDelegate {}
