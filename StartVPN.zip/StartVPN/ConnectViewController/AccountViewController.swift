import UIKit

class AccountViewController: UIViewController {

    private let loginContainerTitleLabel = UILabel()
    private let registerContainerTitleLabel = UILabel()
    private let languagesContainerTitleLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black

        setupAccountContent()
        updateTranslations() // Обновляем текст заголовков при загрузке

        // Подписываемся на уведомления об изменении языка
        NotificationCenter.default.addObserver(self, selector: #selector(updateTranslations), name: .languageChanged, object: nil)
    }

    private func setupAccountContent() {
        // Создаем UIStackView для размещения блоков по центру
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        stackView.distribution = .equalSpacing
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        // Login Block
        let loginContainer = createRoundedBlock(
            titleLabel: loginContainerTitleLabel,
            icon: UIImage(systemName: "person.crop.circle.fill"),
            backgroundColor: UIColor(named: "accaunt_button") ?? .gray,
            action: #selector(navigateToLogin)
        )

        // Register Block
        let registerContainer = createRoundedBlock(
            titleLabel: registerContainerTitleLabel,
            icon: UIImage(systemName: "person.crop.circle.badge.plus"),
            backgroundColor: UIColor(named: "accaunt_button") ?? .gray,
            action: #selector(navigateToRegister) // Добавляем действие
        )

        // Languages Block
        let languagesContainer = createRoundedBlock(
            titleLabel: languagesContainerTitleLabel,
            icon: UIImage(systemName: "globe"),
            backgroundColor: UIColor(named: "accaunt_button") ?? .gray,
            action: #selector(navigateToLanguages)
        )

        // Добавляем блоки в стек
        stackView.addArrangedSubview(loginContainer)
        stackView.addArrangedSubview(registerContainer)
        stackView.addArrangedSubview(languagesContainer)

        // Настройка ограничений для стекового представления
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),

            loginContainer.heightAnchor.constraint(equalToConstant: 60),
            registerContainer.heightAnchor.constraint(equalToConstant: 60),
            languagesContainer.heightAnchor.constraint(equalToConstant: 60)
        ])
    }

    private func createRoundedBlock(titleLabel: UILabel, icon: UIImage?, backgroundColor: UIColor, action: Selector? = nil) -> UIView {
        let container = UIView()
        container.backgroundColor = backgroundColor
        container.layer.cornerRadius = 12
        container.layer.shadowColor = UIColor.black.cgColor
        container.layer.shadowOpacity = 0.2
        container.layer.shadowOffset = CGSize(width: 0, height: 2)
        container.layer.shadowRadius = 4
        container.translatesAutoresizingMaskIntoConstraints = false

        let iconImageView = UIImageView(image: icon)
        iconImageView.tintColor = UIColor(named: "AccentOrange") ?? UIColor.orange
        iconImageView.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(iconImageView)

        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(titleLabel)

        if let action = action {
            let tapGesture = UITapGestureRecognizer(target: self, action: action)
            container.addGestureRecognizer(tapGesture)
        }

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            titleLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16)
        ])

        return container
    }

    @objc func updateTranslations() {
        DispatchQueue.main.async {
            let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

            let translations: [String: [String: String]] = [
                "login": [
                    "en": "Sign In to EMBrace ID",
                    "zh": "登录EMBrace ID",
                    "ru": "Вход в EMBrace ID",
                    "ar": "تسجيل الدخول إلى EMBrace ID"
                ],
                "register": [
                    "en": "Create EMBrace ID",
                    "zh": "创建EMBrace ID",
                    "ru": "Создать EMBrace ID",
                    "ar": "إنشاء معرف EMBrace"
                ],
                "languages": [
                    "en": "Languages",
                    "zh": "语言",
                    "ru": "Языки",
                    "ar": "اللغات"
                ]
            ]


            self.loginContainerTitleLabel.text = translations["login"]?[selectedLanguage] ?? translations["login"]?["en"]
            self.registerContainerTitleLabel.text = translations["register"]?[selectedLanguage] ?? translations["register"]?["en"]
            self.languagesContainerTitleLabel.text = translations["languages"]?[selectedLanguage] ?? translations["languages"]?["en"]

            print("UI updated for language: \(selectedLanguage)")
        }
    }

    @objc private func navigateToLogin() {
        let loginVC = LoginViewController()
        presentOrPushViewController(loginVC)
    }

    @objc private func navigateToRegister() {
        let registerVC = RegisterViewController()
        presentOrPushViewController(registerVC)
    }

    @objc private func navigateToLanguages() {
        let languagesVC = LanguesViewController_login()
        languagesVC.languageManager = LanguageManager.shared // Устанавливаем LanguageManager
        presentOrPushViewController(languagesVC)
    }

    private func presentOrPushViewController(_ viewController: UIViewController) {
        if let navigationController = navigationController {
            navigationController.pushViewController(viewController, animated: true)
        } else {
            viewController.modalPresentationStyle = .fullScreen
            present(viewController, animated: true, completion: nil)
        }
    }

    deinit {
        NotificationCenter.default.removeObserver(self, name: .languageChanged, object: nil)
    }
}
