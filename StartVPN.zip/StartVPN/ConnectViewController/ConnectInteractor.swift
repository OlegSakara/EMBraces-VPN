//
//  ConnectInteractor.swift
//  StartVPN
//
//  Created by Дмитрий Садырев on 06.06.2022.
//  Copyright (c) 2022 ___ORGANIZATIONNAME___. All rights reserved.
//

import UIKit

protocol ConnectBusinessLogic {
    func makeRequest(request: Connect.Model.Request.RequestType)
}

class ConnectInteractor: ConnectBusinessLogic {

    var presenter: ConnectPresentationLogic?
    var service: ConnectService?

    init(service: ConnectService? = nil) {
        self.service = service ?? ConnectService()
        self.service?.interactor = self
    }

    func makeRequest(request: Connect.Model.Request.RequestType) {
        guard let service = service else {
            print("[ConnectInteractor] Service is not initialized.")
            return
        }

        switch request {
        case .countryButtonTouch:
            // Обрабатываем нажатие кнопки выбора страны
            presenter?.presentData(response: .presentCountries)

        case .didSelectCountry(country: let country):
            // Обрабатываем выбор страны
            service.selectedCountry = country
            presenter?.presentData(response: .presentCountry(country: country))

        case .startButtonTouch:
            // Обрабатываем нажатие кнопки подключения
            service.startConnecting()

        case .showError(title: let title, message: let message):
            // Показываем ошибку
            presenter?.presentData(response: .presentError(title: title, message: message))

        case .showPasswordAlert:
            // Показываем алерт для ввода пароля
            presenter?.presentData(response: .presentPasswordAlert)

        case .viewDidDisappear:
            // Обрабатываем событие, когда экран исчез
            service.stopConnecting()

        case .statusChangedToConnecting:
            // Обновляем статус на "Подключение"
            presenter?.presentData(response: .presentStatusConnecting)

        case .statusChangedToConnected:
            // Обновляем статус на "Подключено"
            presenter?.presentData(response: .presentStatusConnected)

        case .statusChangedToDisconnected:
            // Обновляем статус на "Отключено"
            presenter?.presentData(response: .presentStatusDisconnected)

        case .updateTimer(timer: let timer):
            // Обновляем таймер подключения
            presenter?.presentData(response: .presentTimer(timer: timer))

        case .updateTrafficStats(upload: let upload, download: let download):
            // Обновляем статистику трафика
            presenter?.presentData(response: .presentTrafficStats(upload: upload, download: download))

        case .showMap(index: let index):
            // Показать карту
            presenter?.presentData(response: .presentMap(index: index))

        case .didUpdatePassword(password: let password):
            // Сохраняем новый пароль и начинаем подключение
            UserDefaults.standard.set(password, forKey: "password")
            service.startConnecting()

        case .didSelectProtocol(index: let index):
            // Выбираем сетевой протокол с проверкой индекса
            let allProtocols = NetworkProtocol.allCases
            if index >= 0 && index < allProtocols.count {
                service.networkProtocol = allProtocols[index]
            } else {
                print("[ConnectInteractor] Invalid protocol index: \(index)")
            }


        case .disconnect:
            // Разрыв соединения
            service.stopConnecting()
            presenter?.presentData(response: .presentStatusDisconnected)
        }
    }
}
