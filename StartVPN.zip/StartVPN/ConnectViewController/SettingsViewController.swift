import UIKit
import SwiftUI

class SettingsViewController: UIViewController {
    static var isRTLActive: Bool = false
    
    private let boltImage = UIImage(systemName: "bolt")
    private let shieldImage = UIImage(systemName: "shield")
    private let textFormatImage = UIImage(systemName: "textformat")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        setupNavigationBar()
        setupSettingsContent()
        
        // Подписываемся на изменения состояния RTL или языка
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleLanguageOrRTLChange),
            name: .languageChanged,
            object: nil
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleLanguageOrRTLChange),
            name: .rtlStateChanged,
            object: nil
        )
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(customView: UIView()) // Скрываем кнопку "Назад"
        
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    private func setupNavigationBar() {
        // Скрываем встроенную кнопку "Назад"
        navigationItem.hidesBackButton = true

        // Создаем контейнер для навигационной панели
        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        // Настраиваем кнопку "Назад"
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

        // Создаем заголовок с текстом перевода
        let titleLabel = UILabel()
        titleLabel.text = getTitleForNavigationBar() // Используем функцию для перевода заголовка
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        // Добавляем элементы в контейнер
        navigationContainer.addSubview(backButton)
        navigationContainer.addSubview(titleLabel)

        // Устанавливаем ограничения для контейнера
        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60)
        ])

        // Устанавливаем ограничения для кнопки "Назад"
        NSLayoutConstraint.activate([
            backButton.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButton.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor, constant: 16),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        // Устанавливаем ограничения для заголовка
        NSLayoutConstraint.activate([
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor)
        ])
    }

    private func getTitleForNavigationBar() -> String {
        let translations: [String: [String: String]] = [
            "settings": [
                "en": "Settings",
                "zh": "设置",
                "ru": "Настройки",
                "ar": "الإعدادات"
            ]
        ]

        let currentLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
        return translations["settings"]?[currentLanguage] ?? "Settings"
    }

    private func setupSettingsContent() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        // Используем корректные ключи для перевода
        stackView.addArrangedSubview(
            createSettingsRow(iconImage: boltImage, titleKey: "energy_saving", isSwitchVisible: false, additionalText: "coming_soon")
        )
        stackView.addArrangedSubview(
            createSettingsRow(iconImage: shieldImage, titleKey: "block_ads", isSwitchVisible: false, additionalText: "coming_soon")
        )
        stackView.addArrangedSubview(
            createSettingsRow(iconImage: textFormatImage, titleKey: "rtl_display", isSwitchVisible: true, switchAction: #selector(toggleRTLDisplay(_:)))
        )

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }


    private func createSettingsRow(iconImage: UIImage?, titleKey: String, isSwitchVisible: Bool, additionalText: String? = nil, switchAction: Selector? = nil) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false

        let iconImageView = UIImageView(image: iconImage)
        iconImageView.tintColor = .orange
        iconImageView.contentMode = .scaleAspectFit
        iconImageView.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = getTranslation(for: titleKey)
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        container.addSubview(iconImageView)
        container.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            iconImageView.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iconImageView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            titleLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16)
        ])

        if let additionalText = additionalText {
            let additionalLabel = UILabel()
            additionalLabel.text = getTranslation(for: additionalText)
            additionalLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
            additionalLabel.textColor = .gray
            additionalLabel.translatesAutoresizingMaskIntoConstraints = false

            container.addSubview(additionalLabel)
            NSLayoutConstraint.activate([
                additionalLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),
                additionalLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16)
            ])
        }

        if isSwitchVisible {
            let toggleSwitch = UISwitch()
            toggleSwitch.isOn = SettingsViewController.isRTLActive
            toggleSwitch.onTintColor = .orange
            toggleSwitch.translatesAutoresizingMaskIntoConstraints = false
            toggleSwitch.addTarget(self, action: switchAction ?? #selector(defaultSwitchAction(_:)), for: .valueChanged)

            container.addSubview(toggleSwitch)
            NSLayoutConstraint.activate([
                toggleSwitch.centerYAnchor.constraint(equalTo: container.centerYAnchor),
                toggleSwitch.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16)
            ])
        }

        let separatorLine = UIView()
        separatorLine.backgroundColor = UIColor(white: 1.0, alpha: 0.2)
        separatorLine.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(separatorLine)

        NSLayoutConstraint.activate([
            separatorLine.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            separatorLine.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            separatorLine.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            separatorLine.heightAnchor.constraint(equalToConstant: 1)
        ])

        NSLayoutConstraint.activate([
            container.heightAnchor.constraint(greaterThanOrEqualToConstant: 50)
        ])

        return container
    }

    private func getTranslation(for key: String) -> String {
        let translations: [String: [String: String]] = [
            "settings": ["en": "Settings", "zh": "设置", "ru": "Настройки", "ar": "الإعدادات"],
            "energy_saving": ["en": "Energy Saving", "zh": "节能", "ru": "Энергосбережение", "ar": "توفير الطاقة"],
            "block_ads": ["en": "Block Ads", "zh": "拦截广告", "ru": "Блокировать рекламу", "ar": "حجب الإعلانات"],
            "rtl_display": ["en": "RTL Display", "zh": "RTL 显示", "ru": "RTL Отображение", "ar": "عرض من اليمين إلى اليسار"],
            "coming_soon": ["en": "Coming Soon", "zh": "即将推出", "ru": "Скоро будет", "ar": "قريباً"]
        ]

        // Получаем текущий язык
        let currentLanguage = LanguageManager.shared.currentLanguage

        // Проверяем наличие перевода для ключа и языка
        if let languageTranslations = translations[key],
           let translation = languageTranslations[currentLanguage] {
            return translation
        }

        // Возвращаем ключ, если перевод отсутствует
        return key
    }


    @objc private func toggleRTLDisplay(_ sender: UISwitch) {
        SettingsViewController.isRTLActive = sender.isOn
        UIView.appearance().semanticContentAttribute = sender.isOn ? .forceRightToLeft : .forceLeftToRight
        NotificationCenter.default.post(name: .rtlStateChanged, object: nil)
    }

    @objc private func handleLanguageOrRTLChange() {
        reloadCurrentInterface()
    }

    private func reloadCurrentInterface() {
        for subview in view.subviews {
            subview.removeFromSuperview()
        }
        setupNavigationBar()
        setupSettingsContent()
    }

    @objc private func backButtonTapped() {
        self.navigationController?.popViewController(animated: true)
    }

    @objc private func defaultSwitchAction(_ sender: UISwitch) {}
}

extension Notification.Name {
    static let rtlStateChanged = Notification.Name("rtlStateChanged")
}
extension SettingsViewController: UIGestureRecognizerDelegate {}
