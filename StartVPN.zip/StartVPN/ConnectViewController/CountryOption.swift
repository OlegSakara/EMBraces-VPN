import SwiftUI

struct CountryOption: View {
    var countryName: String
    var flagImage: String
    var cityName: String
    var isWiFiGreen: Bool
    var isConnected: Bool
    var isSelectable: Bool
    var onSelect: () -> Void

    @State private var isPressed: Bool = false

    var body: some View {
        ZStack(alignment: .topTrailing) {
            VStack(alignment: .leading, spacing: 8) {
                HStack(spacing: 12) {
                    Image(flagImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: isPad ? 60 : 40, height: isPad ? 60 : 40) // Увеличен размер для iPad
                        .clipShape(Circle())
                }
                HStack(spacing: 12) {
                    Text(countryName)
                        .font(.system(size: isPad ? 20 : 16, weight: .semibold)) // Увеличен шрифт для iPad
                        .foregroundColor(isSelectable ? .white : .gray)
                    Image(systemName: "wifi")
                        .resizable()
                        .scaledToFit()
                        .frame(width: isPad ? 18 : 14, height: isPad ? 18 : 14) // Увеличен размер иконки для iPad
                        .foregroundColor(isWiFiGreen ? .green : .gray)
                        .opacity(isSelectable ? 1.0 : 0.5)
                }
                Text(cityName)
                    .font(.system(size: isPad ? 16 : 12)) // Увеличен шрифт для iPad
                    .foregroundColor(isSelectable ? .gray : Color.gray.opacity(0.5))
                    .padding(.top, -4)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding(isPad ? 24 : 16) // Увеличены отступы для iPad
            .frame(width: isPad ? 260 : 200, height: isPad ? 140 : 100) // Увеличены размеры блока для iPad
            .background(Color("MenuBackgroundColor").edgesIgnoringSafeArea(.all)) // Используем MenuBackgroundColor
            .cornerRadius(isPad ? 24 : 20) // Увеличен радиус углов для iPad
            .overlay(
                RoundedRectangle(cornerRadius: isPad ? 24 : 20)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
            Circle()
                .stroke(isConnected ? .green : .gray, lineWidth: 2)
                .background(isConnected ? Circle().fill(Color.green) : Circle().fill(Color.clear))
                .frame(width: isPad ? 20 : 16, height: isPad ? 20 : 16) // Увеличен размер индикатора для iPad
                .padding(isPad ? 12 : 8)
                .opacity(isSelectable ? 1.0 : 0.5)
        }
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .animation(.easeInOut(duration: 0.2), value: isPressed)
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { _ in if isSelectable { withAnimation { isPressed = true } } }
                .onEnded { _ in if isSelectable { withAnimation { isPressed = false; onSelect() } } }
        )
    }

    private var isPad: Bool {
        UIDevice.current.userInterfaceIdiom == .pad
    }
}

struct CountryOptionsView: View {
    @ObservedObject var languageManager: LanguageManager // Отслеживаем текущий язык
    var onSelect: (String?) -> Void

    @State private var selectedCountry: String? = "Netherlands" // Выбранная страна
    @State private var countries: [Country] = [] // Локальный список стран

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: isPad ? 24 : 16) { // Увеличен отступ между блоками для iPad
                ForEach(countries, id: \.countryName) { country in
                    CountryOption(
                        countryName: translatedCountryName(for: country.countryName),
                        flagImage: country.flagImage,
                        cityName: translatedCityName(for: country.cityName),
                        isWiFiGreen: country.isWiFiGreen,
                        isConnected: selectedCountry == country.countryName,
                        isSelectable: country.isSelectable,
                        onSelect: {
                            selectedCountry = country.countryName
                            onSelect(selectedCountry) // Обрабатываем выбор страны
                        }
                    )
                }
            }
            .padding(.horizontal, isPad ? 24 : 16) // Увеличен отступ для iPad
        }
        .frame(maxWidth: .infinity)
        .background(Color("Menucountry"))
        .padding(.bottom, isPad ? 50 : 0) // Отступ снизу для iPad
        .onAppear {
            // Загружаем список стран при первом отображении
            countries = getCountriesList()
            if let selected = selectedCountry {
                onSelect(selected)
            }
        }
        .onChange(of: languageManager.currentLanguage) { _ in
            // Обновляем страны при изменении языка
            DispatchQueue.main.async {
                countries = getCountriesList()
            }
        }
    }

    private var isPad: Bool {
        UIDevice.current.userInterfaceIdiom == .pad
    }

    // Список стран
    private func getCountriesList() -> [Country] {
        [
            Country(countryName: "Netherlands", flagImage: "netherlands_flag", cityName: "Amsterdam", isWiFiGreen: true, isSelectable: true),
            Country(countryName: "United States", flagImage: "us_flag", cityName: "New York", isWiFiGreen: false, isSelectable: false),
            Country(countryName: "Poland", flagImage: "poland_flag", cityName: "Warsaw", isWiFiGreen: false, isSelectable: false) // Заблокирована
        ]
    }

    // Перевод названия страны
    private func translatedCountryName(for country: String) -> String {
        let translations: [String: [String: String]] = [
            "United States": ["en": "United States", "zh": "美国", "ru": "США", "ar": "الولايات المتحدة"],
            "Netherlands": ["en": "Netherlands", "zh": "荷兰", "ru": "Нидерланды", "ar": "هولندا"],
            "Poland": ["en": "Poland", "zh": "波兰", "ru": "Польша", "ar": "بولندا"]
        ]
        return translations[country]?[languageManager.currentLanguage] ?? country
    }

    // Перевод названия города
    private func translatedCityName(for city: String) -> String {
        let translations: [String: [String: String]] = [
            "New York": ["en": "New York", "zh": "纽约", "ru": "Нью-Йорк", "ar": "نيويورك"],
            "Amsterdam": ["en": "Amsterdam", "zh": "阿姆斯特丹", "ru": "Амстердам", "ar": "أمستردام"],
            "Warsaw": ["en": "Warsaw", "zh": "华沙", "ru": "Варшава", "ar": "وارسو"]
        ]
        return translations[city]?[languageManager.currentLanguage] ?? city
    }

    struct Country {
        let countryName: String
        let flagImage: String
        let cityName: String
        let isWiFiGreen: Bool
        let isSelectable: Bool
    }
}
