//
//  MenuManager.swift
//  EMBREIS
//
//  Created by Vlad Temmo on 26.01.2025.
//
import UIKit
import SwiftUI
import SafariServices

class MenuManager {
    private weak var parentViewController: UIViewController?
    private var dimmedBackgroundView: UIView!
    private var sideMenuView: UIView!
    private var isMenuVisible = false

    // MARK: - Инициализация
    init(parentViewController: UIViewController) {
        self.parentViewController = parentViewController

        // Подписка на уведомления об изменении языка
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(updateMenuTranslations),
            name: .languageChanged,
            object: nil
        )
        addEdgePanGesture()
    }

    deinit {
        NotificationCenter.default.removeObserver(self, name: .languageChanged, object: nil)
    }
    private func addEdgePanGesture() {
            guard let parentViewController = parentViewController else { return }

            let edgePanGesture = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handleEdgePanGesture(_:)))
            edgePanGesture.edges = .left
            parentViewController.view.addGestureRecognizer(edgePanGesture)
        }

        @objc private func handleEdgePanGesture(_ gesture: UIScreenEdgePanGestureRecognizer) {
            guard let parentViewController = parentViewController else { return }

            let translation = gesture.translation(in: parentViewController.view).x
            let sideMenuWidth = calculateSideMenuLayout().0

            switch gesture.state {
            case .changed:
                if translation > 0 {
                    sideMenuView.transform = CGAffineTransform(translationX: min(translation - sideMenuWidth, 0), y: 0)
                    dimmedBackgroundView.isHidden = false
                    dimmedBackgroundView.alpha = min(translation / sideMenuWidth, 0.7)
                }
            case .ended:
                if translation > sideMenuWidth / 2 {
                    toggleSideMenu()
                } else {
                    UIView.animate(withDuration: 0.3) {
                        self.sideMenuView.transform = CGAffineTransform(translationX: -sideMenuWidth, y: 0)
                        self.dimmedBackgroundView.alpha = 0
                        self.dimmedBackgroundView.isHidden = true
                    }
                }
            default:
                break
            }
        }

    // MARK: - Настройка меню
    func setupCustomMenuIcon() {
        guard let parentViewController = parentViewController else { return }

        let (iconSize, leadingOffset, topOffset) = calculateMenuIconLayout()

        let menuIconHostingController = UIHostingController(
            rootView: CustomMenuIcon()
                .frame(width: iconSize, height: iconSize)
        )
        menuIconHostingController.view.translatesAutoresizingMaskIntoConstraints = false
        menuIconHostingController.view.backgroundColor = .clear

        parentViewController.addChild(menuIconHostingController)
        parentViewController.view.addSubview(menuIconHostingController.view)
        menuIconHostingController.didMove(toParent: parentViewController)

        NSLayoutConstraint.activate([
            menuIconHostingController.view.leadingAnchor.constraint(equalTo: parentViewController.view.leadingAnchor, constant: leadingOffset),
            menuIconHostingController.view.topAnchor.constraint(equalTo: parentViewController.view.safeAreaLayoutGuide.topAnchor, constant: topOffset),
            menuIconHostingController.view.widthAnchor.constraint(equalToConstant: iconSize),
            menuIconHostingController.view.heightAnchor.constraint(equalToConstant: iconSize)
        ])

        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(menuButtonTapped))
        menuIconHostingController.view.addGestureRecognizer(tapGesture)
    }

    func setupSideMenu() {
        guard let parentViewController = parentViewController else { return }

        let (sideMenuWidth, dimmedBackgroundAlpha) = calculateSideMenuLayout()

        setupDimmedBackground(withAlpha: dimmedBackgroundAlpha)
        setupSideMenuView(sideMenuWidth: sideMenuWidth)

        addMenuContent()
    }

    private func setupDimmedBackground(withAlpha alpha: CGFloat) {
        guard let parentViewController = parentViewController else { return }

        // Создаем затемненный слой
        dimmedBackgroundView = UIView(frame: UIScreen.main.bounds)
        dimmedBackgroundView.backgroundColor = UIColor.black.withAlphaComponent(alpha) // Постоянное затемнение
        dimmedBackgroundView.alpha = 0 // Изначально невидимо
        dimmedBackgroundView.isHidden = true
        dimmedBackgroundView.isUserInteractionEnabled = true

        // Добавляем жест для закрытия меню
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(hideSideMenu))
        dimmedBackgroundView.addGestureRecognizer(tapGesture)
        
        // Добавляем затемненный слой в иерархию представлений
        parentViewController.view.addSubview(dimmedBackgroundView)
    }


    private func setupSideMenuView(sideMenuWidth: CGFloat) {
        guard let parentViewController = parentViewController else { return }

        sideMenuView = UIView()
        sideMenuView.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? UIColor.black
        sideMenuView.translatesAutoresizingMaskIntoConstraints = false
        sideMenuView.transform = CGAffineTransform(translationX: -sideMenuWidth, y: 0)
        parentViewController.view.addSubview(sideMenuView)

        NSLayoutConstraint.activate([
            sideMenuView.leadingAnchor.constraint(equalTo: parentViewController.view.leadingAnchor),
            sideMenuView.widthAnchor.constraint(equalToConstant: sideMenuWidth),
            sideMenuView.topAnchor.constraint(equalTo: parentViewController.view.topAnchor),
            sideMenuView.bottomAnchor.constraint(equalTo: parentViewController.view.bottomAnchor)
        ])
    }

    private func addMenuContent() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = UIDevice.current.userInterfaceIdiom == .pad ? 35 : 25
        stackView.alignment = .leading
        stackView.translatesAutoresizingMaskIntoConstraints = false
        sideMenuView.addSubview(stackView)

        let preferenceLabel = createMenuTitleLabel()
        stackView.addArrangedSubview(preferenceLabel)

        let menuItems: [(iconName: String, key: String, action: Selector)] = [
            ("slider.horizontal.3", "Settings", #selector(openSettings)),
            ("chart.bar", "Statistics", #selector(openStatistics)),
            ("doc.text", "Privacy Policy", #selector(showPrivatePolicy)),
            ("globe", "Languages", #selector(openLanguages)),
            ("power", "Log out", #selector(logoutUser))
        ]

        for menuItem in menuItems {
            let menuButton = createMenuItem(
                iconName: menuItem.iconName,
                title: getMenuItemTranslation(for: menuItem.key),
                fontSize: UIDevice.current.userInterfaceIdiom == .pad ? 20 : 16
            )
            menuButton.isUserInteractionEnabled = true
            menuButton.addGestureRecognizer(UITapGestureRecognizer(target: self, action: menuItem.action))
            stackView.addArrangedSubview(menuButton)
        }

        let spacerView = UIView()
        spacerView.translatesAutoresizingMaskIntoConstraints = false
        stackView.addArrangedSubview(spacerView)
        spacerView.heightAnchor.constraint(greaterThanOrEqualToConstant: 0).isActive = true

        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: sideMenuView.leadingAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 24 : 16),
            stackView.trailingAnchor.constraint(equalTo: sideMenuView.trailingAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? -24 : -16),
            stackView.topAnchor.constraint(equalTo: sideMenuView.topAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 40 : 60),
            stackView.bottomAnchor.constraint(lessThanOrEqualTo: sideMenuView.bottomAnchor, constant: -20)
        ])
    }

    private func createMenuTitleLabel() -> UILabel {
        let label = UILabel()
        label.text = getMenuTitleTranslation()
        label.font = UIFont.systemFont(
            ofSize: UIDevice.current.userInterfaceIdiom == .pad ? 34 : 28,
            weight: .regular
        )
        label.textColor = .white
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }

    private func createMenuItem(iconName: String, title: String, fontSize: CGFloat) -> UIView {
        let container = UIStackView()
        container.axis = .horizontal
        container.alignment = .center
        container.spacing = 12

        let iconView = UIImageView(image: UIImage(systemName: iconName))
        iconView.tintColor = .orange
        iconView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            iconView.widthAnchor.constraint(equalToConstant: 24),
            iconView.heightAnchor.constraint(equalToConstant: 24)
        ])

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: fontSize)
        titleLabel.textColor = .white

        container.addArrangedSubview(iconView)
        container.addArrangedSubview(titleLabel)

        return container
    }

    private func calculateMenuIconLayout() -> (CGFloat, CGFloat, CGFloat) {
        #if targetEnvironment(macCatalyst)
        return (60, 16, 16)
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            return (50, 12, 12)
        } else {
            return (40, 8, 8)
        }
        #endif
    }

    private func calculateSideMenuLayout() -> (CGFloat, CGFloat) {
        return (300, 0.85) // Одинаковое затемнение для всех устройств
    }
    
    private func getMenuTitleTranslation() -> String {
        let translations: [String: String] = [
            "en": "Preference",
            "zh": "偏好",
            "ru": "Предпочтения",
            "ar": "التفضيلات"
        ]
        return translations[LanguageManager.shared.currentLanguage] ?? "Preference"
    }

    private func getMenuItemTranslation(for key: String) -> String {
        let translations: [String: [String: String]] = [
            "Settings": ["en": "Settings", "zh": "设置", "ru": "Настройки", "ar": "الإعدادات"],
            "Statistics": ["en": "Statistics", "zh": "统计", "ru": "Статистика", "ar": "الإحصائيات"],
            "Privacy Policy": ["en": "Privacy Policy", "zh": "隐私政策", "ru": "Политика", "ar": "سياسة الخصوصية"],
            "Languages": ["en": "Languages", "zh": "语言", "ru": "Языки", "ar": "اللغات"],
            "Log out": ["en": "Log out", "zh": "退出", "ru": "Выйти", "ar": "تسجيل الخروج"]
        ]
        return translations[key]?[LanguageManager.shared.currentLanguage] ?? key
    }

    // MARK: - Динамическое обновление
    @objc private func updateMenuTranslations() {
        guard let stackView = sideMenuView.subviews.first(where: { $0 is UIStackView }) as? UIStackView else { return }

        // Обновляем заголовок меню
        if let preferenceLabel = stackView.arrangedSubviews.first as? UILabel {
            preferenceLabel.text = getMenuTitleTranslation()
        }

        // Обновляем текст кнопок
        let menuItemsKeys = ["Settings", "Statistics", "Privacy Policy", "Languages", "Log out"]
        for (index, button) in stackView.arrangedSubviews.dropFirst().enumerated() {
            guard let container = button as? UIStackView,
                  let titleLabel = container.arrangedSubviews.last as? UILabel else { continue }
            titleLabel.text = getMenuItemTranslation(for: menuItemsKeys[index])
        }
    }

    // MARK: - Селекторы
    @objc private func menuButtonTapped() {
        toggleSideMenu()
    }

    @objc private func hideSideMenu() {
        if isMenuVisible { toggleSideMenu() }
    }

    private func toggleSideMenu() {
        guard let parentViewController = parentViewController else { return }

        let (sideMenuWidth, dimmedBackgroundFinalAlpha) = calculateSideMenuLayout()

        if isMenuVisible {
            UIView.animate(withDuration: 0.3, animations: {
                self.dimmedBackgroundView.alpha = 0
                self.sideMenuView.transform = CGAffineTransform(translationX: -sideMenuWidth, y: 0)
            }) { _ in
                self.isMenuVisible = false
                self.dimmedBackgroundView.isHidden = true
            }
        } else {
            dimmedBackgroundView.isHidden = false
            UIView.animate(withDuration: 0.3, animations: {
                self.dimmedBackgroundView.alpha = dimmedBackgroundFinalAlpha
                self.sideMenuView.transform = .identity
            }) { _ in
                self.isMenuVisible = true
            }
        }
    }

    @objc private func openSettings() {
        guard let parentViewController = parentViewController else { return }
        let settingsVC = SettingsViewController()
        parentViewController.navigationController?.pushViewController(settingsVC, animated: true)
    }

    @objc private func openStatistics() {
        guard let parentViewController = parentViewController else { return }
        let statisticsVC = StatisticsViewController()
        parentViewController.navigationController?.pushViewController(statisticsVC, animated: true)
    }

    @objc private func openLanguages() {
        guard let parentViewController = parentViewController else { return }
        let languagesVC = LanguesViewController()
        languagesVC.languageManager = LanguageManager.shared
        parentViewController.navigationController?.pushViewController(languagesVC, animated: true)
    }

    @objc private func showPrivatePolicy() {
        guard let parentViewController = parentViewController else { return }
        if let url = URL(string: "https://embraces.ru/privacy_for_apple?languageRadio=en") {
            let safariVC = SFSafariViewController(url: url)
            parentViewController.present(safariVC, animated: true)
        }
    }

    @objc private func logoutUser() {
        guard let parentViewController = parentViewController else { return }
        UserDefaults.standard.set(false, forKey: "isLoggedIn")
        UserDefaults.standard.removeObject(forKey: "username")
        UserDefaults.standard.synchronize()

        if let navigationController = parentViewController.navigationController {
            if let accountVC = navigationController.viewControllers.first(where: { $0 is AccountViewController }) as? AccountViewController {
                navigationController.popToViewController(accountVC, animated: true)
            } else {
                let accountVC = AccountViewController()
                navigationController.setViewControllers([accountVC], animated: true)
            }
        } else {
            let accountVC = AccountViewController()
            accountVC.modalPresentationStyle = .fullScreen
            parentViewController.present(accountVC, animated: true, completion: nil)
        }
    }
}
