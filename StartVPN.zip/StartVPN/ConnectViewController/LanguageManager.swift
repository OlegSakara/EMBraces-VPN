import Foundation
import Combine

/// Менеджер языков для приложения.
/// Обеспечивает управление текущим языком и уведомляет другие части приложения об изменении языка.
class LanguageManager: ObservableObject {
    // Singleton для удобного доступа
    static let shared = LanguageManager()
    
    // Текущий язык приложения
    @Published private(set) var currentLanguage: String

    // Поддерживаемые языки
    private let supportedLanguages = ["en", "zh", "ru", "ar"] // Добавлен арабский язык

    // Ключ для сохранения языка в UserDefaults
    private static let languageKey = "AppLanguage"

    private init() {
        // Проверяем сохраненный язык в UserDefaults
        let storedLanguage = UserDefaults.standard.string(forKey: Self.languageKey)
        
        // Если язык недействителен или отсутствует, устанавливаем язык по умолчанию (английский)
        if let storedLanguage = storedLanguage, supportedLanguages.contains(storedLanguage) {
            self.currentLanguage = storedLanguage
        } else {
            self.currentLanguage = "en" // Язык по умолчанию
            saveLanguage("en")
        }
    }

    /// Устанавливает новый язык для приложения.
    /// - Parameter language: Код нового языка (например, "en", "zh", "ru", "ar").
    func setLanguage(_ language: String) {
        guard supportedLanguages.contains(language), language != currentLanguage else {
            return // Если язык уже выбран или не поддерживается, ничего не делаем
        }

        print("Язык изменен на: \(language)")

        // Сохраняем новый язык и уведомляем об изменении
        saveLanguage(language)
        NotificationCenter.default.post(name: .languageChanged, object: nil)
    }

    /// Сохраняет текущий язык в `UserDefaults`.
    /// - Parameter language: Код языка для сохранения.
    private func saveLanguage(_ language: String) {
        UserDefaults.standard.set(language, forKey: Self.languageKey)
        UserDefaults.standard.synchronize()
        currentLanguage = language
    }
}

extension Notification.Name {
    /// Уведомление об изменении языка
    static let languageChanged = Notification.Name("LanguageManager.languageChanged")
}
