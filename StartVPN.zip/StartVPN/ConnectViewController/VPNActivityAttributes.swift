//
//  VPNActivityAttributes.swift
//  EMBREIS
//
//  Created by Vlad Temmo on 30.01.2025.
//
import ActivityKit

struct VPNActivityAttributes: ActivityAttributes {
    struct ContentState: Codable, Hashable {
        var status: String
    }
    
    var sessionID: String
}

