import UIKit

class StatisticsViewController: UIViewController {
    // Icons for rows
    private let boltImage = UIImage(systemName: "square.and.arrow.down")
    private let shieldImage = UIImage(systemName: "square.and.arrow.up")
    private let globeImage = UIImage(systemName: "house")

    private var downloadRow: UIView?
    private var uploadRow: UIView?
    private var countryRow: UIView?
    private var timer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black

        setupNavigationBar()
        setupSettingsContent()
        startUpdatingTrafficStats()
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        NotificationCenter.default.addObserver(self, selector: #selector(updateTranslations), name: .languageChanged, object: nil)
    }

    deinit {
        timer?.invalidate()
        NotificationCenter.default.removeObserver(self)
    }

    // MARK: - Setup Navigation Bar
    private func setupNavigationBar() {
        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        backButton.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = translate(for: "Statistics")
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        navigationContainer.addSubview(backButton)
        navigationContainer.addSubview(titleLabel)

        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60),

            backButton.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButton.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor, constant: 16),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor)
        ])
    }

    // MARK: - Setup Settings Content
    private func setupSettingsContent() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        downloadRow = createSettingsRow(iconImage: boltImage, title: translate(for: "Download"), additionalText: formatSpeed(0.0))
        uploadRow = createSettingsRow(iconImage: shieldImage, title: translate(for: "Upload"), additionalText: formatSpeed(0.0))
        countryRow = createSettingsRow(iconImage: globeImage, title: translate(for: "Country"), additionalText: translate(for: "Loading..."))

        [downloadRow, uploadRow, countryRow].forEach { row in
            if let row = row {
                stackView.addArrangedSubview(row)
            }
        }

        fetchCountryFromIP { [weak self] country in
            DispatchQueue.main.async {
                if let countryRow = self?.countryRow,
                   let additionalLabel = countryRow.subviews.compactMap({ $0 as? UILabel }).last {
                    additionalLabel.text = country
                }
            }
        }

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    // MARK: - Create Row
    private func createSettingsRow(iconImage: UIImage?, title: String, additionalText: String) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false

        let iconImageView = UIImageView(image: iconImage)
        iconImageView.tintColor = .orange
        iconImageView.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        let additionalLabel = UILabel()
        additionalLabel.text = additionalText
        additionalLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular)
        additionalLabel.textColor = .gray
        additionalLabel.textAlignment = .right
        additionalLabel.translatesAutoresizingMaskIntoConstraints = false

        let separatorLine = UIView()
        separatorLine.backgroundColor = UIColor(white: 1.0, alpha: 0.2)
        separatorLine.translatesAutoresizingMaskIntoConstraints = false

        container.addSubview(iconImageView)
        container.addSubview(titleLabel)
        container.addSubview(additionalLabel)
        container.addSubview(separatorLine)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),

            additionalLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            additionalLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: additionalLabel.leadingAnchor, constant: -8),

            separatorLine.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            separatorLine.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            separatorLine.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            separatorLine.heightAnchor.constraint(equalToConstant: 1),

            container.heightAnchor.constraint(equalToConstant: 50)
        ])

        return container
    }

    // MARK: - Update Translations
    @objc private func updateTranslations() {
        if let downloadRow = downloadRow, let downloadTitle = downloadRow.subviews.compactMap({ $0 as? UILabel }).first {
            downloadTitle.text = translate(for: "Download")
        }
        if let uploadRow = uploadRow, let uploadTitle = uploadRow.subviews.compactMap({ $0 as? UILabel }).first {
            uploadTitle.text = translate(for: "Upload")
        }
        if let countryRow = countryRow, let countryTitle = countryRow.subviews.compactMap({ $0 as? UILabel }).first {
            countryTitle.text = translate(for: "Country")
        }
    }

    private func startUpdatingTrafficStats() {
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.updateTrafficStats()
        }
    }

    private func updateTrafficStats() {
        let uploadSpeedValue = formatSpeed(Double.random(in: 10.0...20.0))
        let downloadSpeedValue = formatSpeed(Double.random(in: 50.0...100.0))

        DispatchQueue.main.async {
            if let downloadRow = self.downloadRow, let downloadLabel = downloadRow.subviews.compactMap({ $0 as? UILabel }).last {
                downloadLabel.text = downloadSpeedValue
            }
            if let uploadRow = self.uploadRow, let uploadLabel = uploadRow.subviews.compactMap({ $0 as? UILabel }).last {
                uploadLabel.text = uploadSpeedValue
            }
        }
    }

    private func formatSpeed(_ speed: Double) -> String {
        let unit = translate(for: "Mbps")
        return String(format: "%.1f \(unit)", speed)
    }

    // MARK: - Country Fetching
    private func fetchCountryFromIP(completion: @escaping (String) -> Void) {
        fetchIPv4Address { ipAddress in
            let url = URL(string: "https://ipapi.co/\(ipAddress)/country_name/")!

            let task = URLSession.shared.dataTask(with: url) { data, _, error in
                guard error == nil, let data = data, let country = String(data: data, encoding: .utf8) else {
                    completion("Unavailable")
                    return
                }
                completion(country.trimmingCharacters(in: .whitespacesAndNewlines))
            }
            task.resume()
        }
    }

    private func fetchIPv4Address(completion: @escaping (String) -> Void) {
        let url = URL(string: "https://api.ipify.org?format=json")!

        let task = URLSession.shared.dataTask(with: url) { data, _, error in
            guard error == nil, let data = data else {
                completion("Unavailable")
                return
            }

            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let ip = json["ip"] as? String {
                    completion(ip)
                } else {
                    completion("Unavailable")
                }
            } catch {
                completion("Unavailable")
            }
        }
        task.resume()
    }

    // MARK: - Helpers
    private func translate(for key: String) -> String {
        let translations: [String: [String: String]] = [
            "Statistics": ["en": "Statistics", "ru": "Статистика", "zh": "统计数", "ar": "إحصائيات"],
            "Download": ["en": "Download", "ru": "Загрузка", "zh": "下载", "ar": "تنزيل"],
            "Upload": ["en": "Upload", "ru": "Выгрузка", "zh": "上传", "ar": "تحميل"],
            "Country": ["en": "Country", "ru": "Страна", "zh": "国家", "ar": "الدولة"],
            "Loading...": ["en": "Loading...", "ru": "Загрузка...", "zh": "加载中...", "ar": "جارٍ التحميل..."],
            "Mbps": ["en": "Mbps", "ru": "Мбит/с", "zh": "兆比特每秒", "ar": "ميغابت/ثانية"]
        ]

        let language = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
        return translations[key]?[language] ?? key
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
}
extension StatisticsViewController: UIGestureRecognizerDelegate {}
