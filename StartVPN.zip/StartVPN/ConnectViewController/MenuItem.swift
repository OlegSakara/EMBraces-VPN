import SwiftUI

struct MenuItem: View {
    var icon: String
    var title: String
    var isSwitchOn: Binding<Bool>?

    var body: some View {
        HStack(spacing: UIDevice.current.userInterfaceIdiom == .pad ? 16 : 12) {
            Image(systemName: icon)
                .resizable()
                .scaledToFit()
                .frame(
                    width: UIDevice.current.userInterfaceIdiom == .pad ? 32 : 24,
                    height: UIDevice.current.userInterfaceIdiom == .pad ? 32 : 24
                )
                .foregroundColor(.orange)

            Text(title)
                .font(.system(size: UIDevice.current.userInterfaceIdiom == .pad ? 20 : 16, weight: .regular))
                .foregroundColor(.white)

            Spacer()

            if let isSwitchOn = isSwitchOn {
                Toggle("", isOn: isSwitchOn)
                    .labelsHidden()
                    .toggleStyle(SwitchToggleStyle(tint: .orange)) // Оранжевый переключатель
            }
        }
        .padding(.horizontal, UIDevice.current.userInterfaceIdiom == .pad ? 16 : 8)
        .frame(height: UIDevice.current.userInterfaceIdiom == .pad ? 60 : 44) // Увеличиваем высоту строки для iPad
    }
}
