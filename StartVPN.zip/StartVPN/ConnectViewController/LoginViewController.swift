import UIKit

class LoginViewController: UIViewController, UITextFieldDelegate {
    private let mandatoryLabel = UILabel()
    private let continueButton = UIButton(type: .system)
    private let inputField = UITextField()
    private let messageLabel = UILabel()
    var preloadedUsername: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        setupNavigationBar()
        setupUI()
        setupDismissKeyboardGesture()
        updateInputFieldTranslations()
        
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        
        if let username = preloadedUsername {
                inputField.text = username
                continueButton.isEnabled = true
                continueButton.layer.borderColor = UIColor.systemOrange.cgColor
                continueButton.backgroundColor = UIColor.systemOrange
                mandatoryLabel.isHidden = true
            }
    }

    private func setupDismissKeyboardGesture() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        tapGesture.cancelsTouchesInView = false
        view.addGestureRecognizer(tapGesture)
    }

    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    private func setupNavigationBar() {
        navigationItem.hidesBackButton = true

        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)
        navigationContainer.addSubview(backButton)

        let titleLabel = UILabel()
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        // Получаем текущий язык
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Добавляем перевод заголовка
        let titleTranslations = [
            "en": "Authorization",
            "zh": "授权",
            "ru": "Авторизация",
            "ar": "تفويض"
        ]
        titleLabel.text = titleTranslations[selectedLanguage] ?? "Login"

        navigationContainer.addSubview(titleLabel)

        // Определяем отступ для iPad и iPhone
        let topPadding: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 50 : 75 // Уменьшенный отступ для iPad

        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.topAnchor, constant: topPadding),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60),

            backButton.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor, constant: 8),
            backButton.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44),

            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor),
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor)
        ])
    }


    private func updateInputFieldTranslations() {
        // Получаем текущий язык из настроек приложения или используем "en" по умолчанию
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
        
        // Перевод для заголовка ввода
        inputField.placeholder = [
            "en": "Enter Username",
            "zh": "输入用户名",
            "ru": "Введите имя пользователя",
            "ar": "أدخل اسم المستخدم"
        ][selectedLanguage] ?? "Enter Username"
    }


    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }

    private func setupUI() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 16
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        stackView.addArrangedSubview(createInputFieldContainer())
        setupContinueButton()
        stackView.addArrangedSubview(continueButton)
        setupMessageLabel()
        stackView.addArrangedSubview(messageLabel)

        NSLayoutConstraint.activate([
            stackView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func createInputFieldContainer() -> UIView {
        let container = UIView()
        container.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        container.layer.cornerRadius = 8
        container.layer.borderWidth = 1
        container.layer.borderColor = UIColor.orange.cgColor
        container.translatesAutoresizingMaskIntoConstraints = false

        // Добавляем жест для активации клавиатуры
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(activateKeyboard))
        container.addGestureRecognizer(tapGesture)

        inputField.font = UIFont.systemFont(ofSize: 14)
        inputField.textColor = .white
        inputField.delegate = self
        inputField.translatesAutoresizingMaskIntoConstraints = false

        // Устанавливаем плейсхолдер с белым цветом и мягкой прозрачностью
        let placeholderText = NSLocalizedString("Enter Username", comment: "Input Placeholder")
        inputField.attributedPlaceholder = NSAttributedString(
            string: placeholderText,
            attributes: [.foregroundColor: UIColor.white.withAlphaComponent(0.6)]
        )

        // Добавляем поле ввода в контейнер
        container.addSubview(inputField)

        // Настраиваем метку обязательности
        mandatoryLabel.font = UIFont.systemFont(ofSize: 12)
        mandatoryLabel.textColor = .red
        mandatoryLabel.text = NSLocalizedString("Required", comment: "Mandatory Label")
        mandatoryLabel.translatesAutoresizingMaskIntoConstraints = false
        mandatoryLabel.isHidden = true
        container.addSubview(mandatoryLabel)

        // Настройка Auto Layout
        NSLayoutConstraint.activate([
            container.heightAnchor.constraint(equalToConstant: 60),

            inputField.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            inputField.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            inputField.trailingAnchor.constraint(lessThanOrEqualTo: mandatoryLabel.leadingAnchor, constant: -8),

            mandatoryLabel.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            mandatoryLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor)
        ])

        return container
    }
    
    
    @objc private func activateKeyboard() {
        inputField.becomeFirstResponder()
    }
    
    

    private func setupMessageLabel() {
        messageLabel.textColor = .red
        messageLabel.font = UIFont.systemFont(ofSize: 16)
        messageLabel.textAlignment = .center
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
    }

    private func setupContinueButton() {
        // Получаем текущий язык из настроек
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Перевод текста кнопки
        let buttonTitle = [
            "en": "Sign In",
            "zh": "登录",
            "ru": "Войти",
            "ar": "تسجيل الدخول"
        ][selectedLanguage] ?? "Sign In"

        // Настраиваем внешний вид кнопки
        continueButton.setTitle(buttonTitle, for: .normal)
        continueButton.setTitleColor(.lightGray, for: .normal)
        continueButton.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        continueButton.layer.cornerRadius = 12
        continueButton.layer.borderWidth = 1
        continueButton.layer.borderColor = UIColor.lightGray.cgColor
        continueButton.titleLabel?.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        continueButton.translatesAutoresizingMaskIntoConstraints = false

        // Добавляем цель для нажатия на кнопку
        continueButton.addTarget(self, action: #selector(continueButtonTapped), for: .touchUpInside)
        continueButton.isEnabled = false

        // Задаем фиксированную высоту кнопки
        NSLayoutConstraint.activate([
            continueButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }



    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Текущее и обновленное значение текста
        guard let currentText = textField.text,
              let textRange = Range(range, in: currentText) else { return true }
        let updatedText = currentText.replacingCharacters(in: textRange, with: string)
        
        // Проверка валидности текста
        let isInputValid = updatedText.count >= 3
        
        // Обновляем состояние кнопки, только если статус изменился
        if continueButton.isEnabled != isInputValid {
            updateContinueButtonState(isEnabled: isInputValid)
        }
        
        return true
    }

    // Вспомогательный метод для обновления состояния кнопки
    private func updateContinueButtonState(isEnabled: Bool) {
        continueButton.isEnabled = isEnabled
        continueButton.setTitleColor(isEnabled ? .white : .lightGray, for: .normal)
        continueButton.layer.borderColor = isEnabled ? UIColor.systemOrange.cgColor : UIColor.lightGray.cgColor
        continueButton.backgroundColor = isEnabled ? UIColor.systemOrange : UIColor.lightGray.withAlphaComponent(0.2)
    }


    @objc private func continueButtonTapped() {
        guard let username = inputField.text?.trimmingCharacters(in: .whitespacesAndNewlines), !username.isEmpty else {
            messageLabel.text = NSLocalizedString("Please enter a username", comment: "Error Message")
            return
        }
        validateUser(username: username)
    }

    /// Метод проверки пользователя через API
    /// Метод проверки пользователя через API
    private func validateUser(username: String) {
        guard let url = URL(string: "https://embraces.ru/API/Google/API_android.php") else {
            showMessage(translate("Invalid server URL"), isError: true)
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        request.setValue("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36", forHTTPHeaderField: "User-Agent")
        let credentials = "username=\(username)&password=\(username)"
        request.httpBody = credentials.data(using: .utf8)
        
        // Добавляем авторизацию (Basic Auth)
        let apiUser = "yCrtWUuZt0MM"
        let apiPassword = "yCrtWUuZt0MM"
        let loginString = "\(apiUser):\(apiPassword)"
        guard let loginData = loginString.data(using: .utf8) else {
            showMessage(translate("Failed to encode credentials"), isError: true)
            return
        }
        let base64LoginString = loginData.base64EncodedString()
        request.setValue("Basic \(base64LoginString)", forHTTPHeaderField: "Authorization")
        
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let self = self else { return }
            
            if let error = error {
                DispatchQueue.main.async {
                    let errorMessage = self.translate("Network error: %@").replacingOccurrences(of: "%@", with: error.localizedDescription)
                    self.showMessage(errorMessage, isError: true)
                }
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.showMessage(self.translate("No response from server"), isError: true)
                }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    self.showMessage(self.translate("No data received from server"), isError: true)
                }
                return
            }
            
            print("[API Response] Status Code: \(httpResponse.statusCode)")
            if httpResponse.statusCode == 200 {
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                        let success = json["success"] as? Bool ?? false
                        if success {
                            if let users = json["names"] as? [String], users.contains(username) {
                                DispatchQueue.main.async {
                                    // Сохраняем состояние входа
                                    UserDefaults.standard.set(true, forKey: "isLoggedIn")
                                    UserDefaults.standard.set(username, forKey: "username")
                                    UserDefaults.standard.synchronize()

                                    // Переходим на ConnectViewController
                                    self.navigateToConnectViewController(username: username)
                                }
                            } else {
                                DispatchQueue.main.async {
                                    self.showMessage(self.translate("Sorry, but such user does not exist."), isError: true)
                                }
                            }
                        } else {
                            let errorMessage = json["message"] as? String ?? self.translate("Unknown error")
                            DispatchQueue.main.async {
                                self.showMessage(errorMessage, isError: true)
                            }
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.showMessage(self.translate("Invalid server response"), isError: true)
                        }
                    }
                } catch {
                    let errorMessage = self.translate("Error processing server response: %@").replacingOccurrences(of: "%@", with: error.localizedDescription)
                    DispatchQueue.main.async {
                        self.showMessage(errorMessage, isError: true)
                    }
                }
            } else {
                DispatchQueue.main.async {
                    let errorMessage = self.translate("Error: Server returned code \(httpResponse.statusCode)")
                    self.showMessage(errorMessage, isError: true)
                }
            }
        }.resume()
    }

    private func showMessage(_ message: String, isError: Bool = false) {
        DispatchQueue.main.async {
            self.messageLabel.text = message
            self.messageLabel.textColor = isError ? .red : .white
        }
    }

    
    private func translate(_ text: String) -> String {
        // Получаем текущий язык
        let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"

        // Словарь переводов
        let translations: [String: [String: String]] = [
            "Invalid server URL": [
                "en": "Invalid server URL",
                "zh": "无效的服务器URL",
                "ru": "Неверный URL сервера",
                "ar": "عنوان URL غير صالح"
            ],
            "Network error: %@": [
                "en": "Network error: %@",
                "zh": "网络错误: %@",
                "ru": "Сетевая ошибка: %@",
                "ar": "خطأ في الشبكة: %@"
            ],
            "No response from server": [
                "en": "No response from server",
                "zh": "服务器无响应",
                "ru": "Нет ответа от сервера",
                "ar": "لا يوجد استجابة من الخادم"
            ],
            "Sorry, but such user does not exist.": [
                "en": "Sorry, but such user does not exist.",
                "zh": "抱歉，该用户不存在。",
                "ru": "Извините, но такого пользователя не существует.",
                "ar": "عذرًا، هذا المستخدم غير موجود."
            ],
            "Unknown error": [
                "en": "Unknown error",
                "zh": "未知错误",
                "ru": "Неизвестная ошибка",
                "ar": "خطأ غير معروف"
            ],
            "Invalid server response": [
                "en": "Invalid server response",
                "zh": "服务器响应无效",
                "ru": "Неверный ответ от сервера",
                "ar": "استجابة غير صالحة من الخادم"
            ],
            "Error processing server response: %@": [
                "en": "Error processing server response: %@",
                "zh": "处理服务器响应时出错: %@",
                "ru": "Ошибка обработки ответа сервера: %@",
                "ar": "خطأ في معالجة استجابة الخادم: %@"
            ],
        ]

        // Возвращаем перевод текста
        return translations[text]?[selectedLanguage] ?? text
    }
    // Реализация UIGestureRecognizerDelegate
        func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
            return true // Разрешаем жест для всех случаев
        }

    private func navigateToConnectViewController(username: String) {
        UserDefaults.standard.set(username, forKey: "username") // Сохраняем имя
        let connectVC = ConnectViewController()
        connectVC.username = username // Передаём имя напрямую
        connectVC.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(connectVC, animated: true)

        // Инициируем подключение
        ConnectService().startConnecting()
    }
    
}
// В самом конце файла
extension LoginViewController: UIGestureRecognizerDelegate {}

