import UIKit

class LanguesViewController: UIViewController {
    var languageManager: LanguageManager! // Добавляем LanguageManager

    private let boltImage = UIImage(systemName: "globe")
    private let shieldImage = UIImage(systemName: "globe")
    private let globeImage = UIImage(systemName: "globe") // Icon for Russia
    private let arabicImage = UIImage(systemName: "globe") // Icon for Arabic

    private var switches: [UISwitch] = []
    private let languages: [String] = ["en", "zh", "ru", "ar"] // Supported language codes
    private let titleLabel = UILabel() // Заголовок делаем свойством класса

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.interactivePopGestureRecognizer?.delegate = self
        assert(languageManager != nil, "LanguageManager должен быть инициализирован!") // Проверка LanguageManager

        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        setupNavigationBar()
        setupSettingsContent()
        updateTitleTranslation() // Обновляем перевод заголовка
    }

    private func setupNavigationBar() {
        // Скрываем встроенную кнопку "Назад"
        navigationItem.hidesBackButton = true

        // Создаем контейнер для кнопки и заголовка
        let navigationContainer = UIView()
        navigationContainer.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(navigationContainer)

        // Настраиваем кнопку "Назад"
        let backButton = UIButton(type: .system)
        backButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        backButton.tintColor = .white
        backButton.imageView?.contentMode = .scaleAspectFit
        backButton.translatesAutoresizingMaskIntoConstraints = false
        backButton.addTarget(self, action: #selector(backButtonTapped), for: .touchUpInside)

        // Настраиваем заголовок
        titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        // Добавляем кнопку и заголовок в контейнер
        navigationContainer.addSubview(backButton)
        navigationContainer.addSubview(titleLabel)

        // Устанавливаем ограничения для контейнера
        NSLayoutConstraint.activate([
            navigationContainer.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            navigationContainer.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            navigationContainer.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            navigationContainer.heightAnchor.constraint(equalToConstant: 60)
        ])

        // Устанавливаем ограничения для кнопки "Назад"
        NSLayoutConstraint.activate([
            backButton.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            backButton.leadingAnchor.constraint(equalTo: navigationContainer.leadingAnchor, constant: 16),
            backButton.widthAnchor.constraint(equalToConstant: 44),
            backButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        // Устанавливаем ограничения для заголовка
        NSLayoutConstraint.activate([
            titleLabel.centerYAnchor.constraint(equalTo: navigationContainer.centerYAnchor),
            titleLabel.centerXAnchor.constraint(equalTo: navigationContainer.centerXAnchor)
        ])
    }

    private func setupSettingsContent() {
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 12
        stackView.alignment = .fill
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stackView)

        let englishRow = createSettingsRow(iconImage: boltImage, title: "English", languageCode: "en")
        let chinaRow = createSettingsRow(iconImage: shieldImage, title: "中文", languageCode: "zh")
        let russiaRow = createSettingsRow(iconImage: globeImage, title: "Русский", languageCode: "ru")
        let arabicRow = createSettingsRow(iconImage: arabicImage, title: "العربية", languageCode: "ar") // Arabic

        stackView.addArrangedSubview(englishRow)
        stackView.addArrangedSubview(chinaRow)
        stackView.addArrangedSubview(russiaRow)
        stackView.addArrangedSubview(arabicRow)

        NSLayoutConstraint.activate([
            stackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 80),
            stackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            stackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func createSettingsRow(iconImage: UIImage?, title: String, languageCode: String) -> UIView {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false

        let iconImageView = UIImageView(image: iconImage)
        iconImageView.tintColor = .orange
        iconImageView.translatesAutoresizingMaskIntoConstraints = false

        let titleLabel = UILabel()
        titleLabel.text = title
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .semibold)
        titleLabel.textColor = .white
        titleLabel.translatesAutoresizingMaskIntoConstraints = false

        let toggleSwitch = UISwitch()
        toggleSwitch.isOn = (languageManager.currentLanguage == languageCode) // Включено для текущего языка
        toggleSwitch.onTintColor = .orange
        toggleSwitch.translatesAutoresizingMaskIntoConstraints = false
        toggleSwitch.tag = switches.count
        toggleSwitch.addTarget(self, action: #selector(switchToggled(_:)), for: .valueChanged)
        switches.append(toggleSwitch)

        container.addSubview(iconImageView)
        container.addSubview(titleLabel)
        container.addSubview(toggleSwitch)

        NSLayoutConstraint.activate([
            iconImageView.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            iconImageView.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            iconImageView.widthAnchor.constraint(equalToConstant: 24),
            iconImageView.heightAnchor.constraint(equalToConstant: 24),

            titleLabel.leadingAnchor.constraint(equalTo: iconImageView.trailingAnchor, constant: 16),
            titleLabel.centerYAnchor.constraint(equalTo: container.centerYAnchor),

            toggleSwitch.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            toggleSwitch.centerYAnchor.constraint(equalTo: container.centerYAnchor),
            container.heightAnchor.constraint(equalToConstant: 50)
        ])

        return container
    }

    @objc private func switchToggled(_ sender: UISwitch) {
        let selectedLanguage = languages[sender.tag]
        languageManager?.setLanguage(selectedLanguage)

        for (index, toggle) in switches.enumerated() {
            toggle.isOn = (index == sender.tag)
        }

        updateTitleTranslation() // Переводим заголовок при смене языка

        DispatchQueue.main.async {
            guard let connectVC = self.findConnectViewController() else { return }
            connectVC.updateAllTranslations()
        }
    }

    private func updateTitleTranslation() {
        let translations: [String: String] = [
            "en": "Languages",
            "zh": "语言",
            "ru": "Языки",
            "ar": "اللغات"
        ]
        titleLabel.text = translations[languageManager.currentLanguage] ?? "Languages"
    }

    private func findConnectViewController() -> ConnectViewController? {
        if let navController = navigationController {
            return navController.viewControllers.first(where: { $0 is ConnectViewController }) as? ConnectViewController
        }
        return nil
    }

    @objc private func backButtonTapped() {
        navigationController?.popViewController(animated: true)
    }
}
extension LanguesViewController: UIGestureRecognizerDelegate {}
