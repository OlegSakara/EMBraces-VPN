//
//  KeychainHelper.swift
//  EMBREIS
//
//  Created by Vlad Temmo on 19.01.2025.
//
// ______ __  __ ____  _____  ______ _____  _____    
//|  ____|  \/  |  _ \|  __ \|  ____|_   _|/ ____|
//| |__  | \  / | |_) | |__) | |__    | | | (___
//|  __| | |\/| |  _ <|  _  /|  __|   | |  \___ \
//| |____| |  | | |_) | | \ \| |____ _| |_ ____) |
//|______|_|  |_|____/|_|  \_\______|_____|_____/
                                                                      
                                                                      
import Foundation
import Security

final class KeychainHelper {

    // MARK: - Singleton
    static let shared = KeychainHelper()
    private init() {}

    // MARK: - Save to Keychain
    /// Сохранение данных в Keychain
    /// - Parameters:
    ///   - value: Данные для сохранения
    ///   - account: Уникальное имя аккаунта
    /// - Returns: Успех операции
    func save(_ value: String, for account: String) -> Bool {
        guard let data = value.data(using: .utf8) else { return false }
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: account,
            kSecValueData as String: data
        ]

        // Удаление старых данных перед сохранением
        SecItemDelete(query as CFDictionary)
        let status = SecItemAdd(query as CFDictionary, nil)
        
        return status == errSecSuccess
    }

    // MARK: - Retrieve from Keychain
    /// Извлечение данных из Keychain
    /// - Parameter account: Уникальное имя аккаунта
    /// - Returns: Извлеченные данные или nil, если они отсутствуют
    func retrieve(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess, let data = result as? Data else { return nil }
        
        return String(data: data, encoding: .utf8)
    }

    // MARK: - Delete from Keychain
    /// Удаление данных из Keychain
    /// - Parameter account: Уникальное имя аккаунта
    /// - Returns: Успех операции
    func delete(for account: String) -> Bool {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrAccount as String: account
        ]
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess
    }
}


