import SwiftUI

struct ConcentricCircleView: View {
    var body: some View {
        ZStack {
            // Внешний круг
            Circle()
                .stroke(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.gray.opacity(0.3), Color.gray.opacity(0.1)]),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: outerCircleLineWidth
                )
                .frame(width: outerCircleSize, height: outerCircleSize) // Размер круга зависит от платформы

            // Средний круг
            Circle()
                .stroke(
                    LinearGradient(
                        gradient: Gradient(colors: [Color.gray.opacity(0.5), Color.gray.opacity(0.2)]),
                        startPoint: .top,
                        endPoint: .bottom
                    ),
                    lineWidth: middleCircleLineWidth
                )
                .frame(width: middleCircleSize, height: middleCircleSize) // Размер круга зависит от платформы
        }
    }

    // MARK: - Адаптивные размеры для iOS, iPad и macOS
    private var outerCircleSize: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 320 // Увеличенный размер для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 280 // Увеличенный размер для iPad
        } else {
            return 240 // Обычный размер для iPhone
        }
        #endif
    }

    private var middleCircleSize: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 280 // Увеличенный размер для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 240 // Увеличенный размер для iPad
        } else {
            return 200 // Обычный размер для iPhone
        }
        #endif
    }

    private var outerCircleLineWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 16 // Толще для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 14 // Средняя толщина для iPad
        } else {
            return 12 // Обычная толщина для iPhone
        }
        #endif
    }

    private var middleCircleLineWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 12 // Толще для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            return 10 // Средняя толщина для iPad
        } else {
            return 8 // Обычная толщина для iPhone
        }
        #endif
    }
}
