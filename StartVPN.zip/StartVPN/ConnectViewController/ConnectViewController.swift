import UIKit
import SwiftUI
import NVActivityIndicatorView
import Network

protocol ConnectDisplayLogic: AnyObject {
    func displayData(viewModel: Connect.Model.ViewModel.ViewModelData)
}

class ConnectViewController: UIViewController, ConnectDisplayLogic {
    var languageManager: LanguageManager!
    private var startButton: UIButton! // Программно созданная кнопка
    private var circleImageView: UIImageView?
    private var connectLabel: UILabel! // Лейбл для текста с анимацией
    private var animationTimer: Timer? // Таймер для анимации точек
    private var selectedCountry: String? // Выбранная локация
    var isConnected: Bool = false
    private var connectionTimer: Timer? // Таймер для отображения времени
    private var connectionStartTime: Date? // Время, когда подключение началось
    private var connectionTimeLabel: UILabel!
    private var connectionInfoLabel: UILabel!
    public var ipLabel: UILabel!
    private var idLabel: UILabel!
    private var speedLabel: UILabel!
    private var isMenuVisible = false
    private var menuHostingController: UIHostingController<CustomMenuIcon>?
    private var sideMenuView: UIView!
    private var dimmedBackgroundView: UIView!
    private var concentricCircleView: UIView?
    private var currentSpeedMbps: Double?
    var connectService: ConnectService?
    var username: String?
    var interactor: ConnectBusinessLogic?
    var router: (NSObjectProtocol & ConnectRoutingLogic)?
    private var isMainScreenActive: Bool = true
    var isConnecting: Bool = false
    private var hostingController: UIHostingController<CountryOptionsView>?
    private var concentricCircleHostingController: UIHostingController<ConcentricCircleView>?
    private var networkMonitor: NWPathMonitor?
    private var menuManager: MenuManager!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        .darkContent
    }
    
    class SceneDelegate: UIResponder, UIWindowSceneDelegate {
        var window: UIWindow?

        func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
            guard let windowScene = (scene as? UIWindowScene) else { return }
            let window = UIWindow(windowScene: windowScene)

            let connectVC = ConnectViewController()
            connectVC.languageManager = LanguageManager.shared // Используем Singleton
            let navController = UINavigationController(rootViewController: connectVC)

            window.rootViewController = navController
            self.window = window
            window.makeKeyAndVisible()
        }
    }
    
    final class SceneDelegateHolder: ObservableObject {
        static let shared = SceneDelegateHolder()

        // Храним подключённые сцены
        @Published var connectedScenes: Set<UIScene> = []

        private init() {}
    }
    // MARK: Object lifecycle
    
    override init(nibName: String?, bundle: Bundle?) {
        super.init(nibName: nibName, bundle: bundle)
        setup()
    }


        required init?(coder aDecoder: NSCoder) {
            super.init(coder: aDecoder)
            setup()
        }
    
    // MARK: Setup
    private func setup() {
        print("[ConnectViewController] Setting up ConnectViewController.")

        // Создаем компоненты
        let viewController = self
        let interactor = ConnectInteractor() // Убираем передачу username
        let presenter = ConnectPresenter()
        let router = ConnectRouter()
        // Настраиваем зависимости
        viewController.interactor = interactor
        viewController.router = router
        interactor.presenter = presenter
        presenter.viewController = viewController
        router.viewController = viewController

        print("[ConnectViewController] Setup completed.")
    }
    
    private func setupSpeedLabel() {
        speedLabel = UILabel()
        speedLabel.textColor = .white
        speedLabel.textAlignment = .right
        speedLabel.numberOfLines = 1
        speedLabel.translatesAutoresizingMaskIntoConstraints = false

        // Установка стиля для macOS, iOS и iPad
        #if targetEnvironment(macCatalyst)
        speedLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular) // Увеличенный шрифт для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            speedLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular) // Шрифт для iPad
        } else {
            speedLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular) // Шрифт для iPhone
        }
        #endif

        view.addSubview(speedLabel)

        NSLayoutConstraint.activate([
            speedLabel.topAnchor.constraint(equalTo: ipLabel.bottomAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 15 : 10), // Больше отступ для iPad
            speedLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])

        // Устанавливаем текст по умолчанию
        updateSpeedLabelTranslation()
    }

    private func setupIDLabel() {
        idLabel = UILabel()
        idLabel.textColor = .white
        idLabel.textAlignment = .right
        idLabel.numberOfLines = 1
        idLabel.alpha = isMainScreenActive ? 1.0 : 0.5
        idLabel.translatesAutoresizingMaskIntoConstraints = false

        // Установка стиля для macOS, iOS и iPad
        #if targetEnvironment(macCatalyst)
        idLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular) // Увеличенный шрифт для macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            idLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular) // Шрифт для iPad
        } else {
            idLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular) // Шрифт для iPhone
        }
        #endif

        view.addSubview(idLabel)

        NSLayoutConstraint.activate([
            idLabel.topAnchor.constraint(equalTo: speedLabel.bottomAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 12 : 8), // Увеличенный отступ для iPad
            idLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])

        // Первоначальная установка текста
        updateIDLabelTranslation()
    }


    private func updateIDLabelTranslation() {
        let selectedLanguage = LanguageManager.shared.currentLanguage

        let idTranslations: [String: String] = [
            "en": "ID: %@",
            "zh": "编号: %@",
            "ru": "Идентификатор: %@",
            "ar": "معرّف: %@"

        ]

        // Получаем строку перевода или используем английский по умолчанию
        let idFormat = idTranslations[selectedLanguage] ?? idTranslations["en"]!

        // Используем имя пользователя или "Unknown" по умолчанию
        let displayedID = username ?? getTranslation(for: "Unknown")

        // Обновляем текст idLabel
        idLabel.text = String(format: idFormat, displayedID)
        print("ID Label updated to: \(idLabel.text ?? "")")
    }

    private func getTranslation(for key: String) -> String {
        let translations: [String: [String: String]] = [
            "Unknown": ["en": "Unknown", "zh": "未知", "ru": "Неизвестно"]
        ]
        let language = LanguageManager.shared.currentLanguage
        return translations[key]?[language] ?? key
    }
    func updateAllTranslations() {
        // Обновляем перевод всех элементов интерфейса
        updateIDLabelTranslation()
        updateSpeedLabelTranslation()
        updateButtonAppearance()
        updateIPLabelTranslation()
        print("[ConnectViewController] Translations updated.")
    }

    private func updateIDLabel() {
            idLabel.text = "ID: \(username ?? "Unknown")"
        }

    private func measureDownloadSpeed() {
        guard let url = URL(string: "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_272x92dp.png") else {
            print("404")
            return
        }

        let startTime = CFAbsoluteTimeGetCurrent()

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let self = self else { return }

            if let error = error {
                print("Ошибка при измерении скорости: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.currentSpeedMbps = nil
                    self.updateSpeedLabelTranslation(speed: nil)
                }
                return
            }

            let endTime = CFAbsoluteTimeGetCurrent()
            let elapsedTime = endTime - startTime

            if let data = data {
                let dataSize = Double(data.count) / (1024 * 1024) // Размер данных в мегабайтах
                let speed = dataSize / elapsedTime // Скорость в мегабайтах в секунду
                let speedMbps = speed * 8 // Скорость в мегабитах в секунду

                // Сохраняем измеренное значение скорости и обновляем метку
                DispatchQueue.main.async {
                    self.currentSpeedMbps = speedMbps
                    self.updateSpeedLabelTranslation(speed: speedMbps)
                }
            }
        }
        task.resume()
    }

    private func updateSpeedLabelTranslation(speed: Double? = nil) {
        let selectedLanguage = LanguageManager.shared.currentLanguage

        let speedTranslations: [String: (String, String)] = [
            "en": ("Speed: %.2f", "Mbps"),
            "zh": ("速度: %.2f", "兆比特每秒"),
            "ru": ("Скорость: %.2f", "Мбит/с"),
            "ar": ("السرعة: %.2f", "ميغابت/ثانية")
        ]

        let translations = speedTranslations[selectedLanguage] ?? speedTranslations["en"]!

        let displayedSpeed = speed ?? currentSpeedMbps ?? 0.0

        speedLabel.text = String(format: "\(translations.0) \(translations.1)", displayedSpeed)
        print("Speed Label updated to: \(speedLabel.text ?? "")")
    }

    
    private func updateStaticIP(_ ip: String) {
        let selectedLanguage = LanguageManager.shared.currentLanguage

        let ipTranslations: [String: String] = [
            "en": "IP: \(ip)",
            "zh": "IP: \(ip)",
            "ru": "IP - адрес: \(ip)"
            
        ]

        ipLabel.text = ipTranslations[selectedLanguage] ?? "IP: \(ip)"
        print("IP Label updated to: \(ipLabel.text ?? "")")
    }

    
    private func updateCountryFlag(for imageName: String?) {
        if let imageName = imageName {
            circleImageView?.isHidden = false
            circleImageView?.image = UIImage(named: imageName)
        } else {
            circleImageView?.isHidden = true
        }
    }
    
    func displayData(viewModel: Connect.Model.ViewModel.ViewModelData) {
        switch viewModel {
        case .displayCountries:
            // Проверяем наличие `router`
            guard let router = router else { return }
            router.showCountries()

        case .displayNavigationTitle(title: let title):
            // Убедимся, что `navigationItem` доступен
            navigationItem.title = title

        case .displayStartButton(image: let image):
            // Проверяем наличие `startButton`
            guard let startButton = startButton else { return }
            startButton.setImage(image, for: .normal)

        case .displayPulsate(isEnable: let isEnable):
            // Проверяем наличие `startButton` перед использованием
            guard let startButton = startButton else { return }
            startButton.pulsate(isEnable)

        default:
            break
        }
    }
    
    // MARK: View lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Скрываем навигационную панель
        navigationController?.setNavigationBarHidden(true, animated: false)
        // Восстанавливаем имя пользователя
        username = fetchSavedUsername()
        // Проверяем наличие имени пользователя
        guard let username = username, !username.isEmpty else {
            print("[ConnectViewController] No username found. Redirecting to LoginViewController.")
            navigateToLogin()
            return
        }
        // Инициализация LanguageManager
        if languageManager == nil {
            print("[Warning] LanguageManager is not initialized. Using shared instance.")
            languageManager = LanguageManager.shared
        }
        // Настраиваем наблюдателя для завершения работы приложения
        setupAppTerminationObserver()
        // Лог для отладки
        print("[ConnectViewController] Loaded with username: \(username)")
        // Настраиваем элементы интерфейса
        configureUI()
        // Восстанавливаем состояние VPN
        restoreVPNState()
        setupNetworkMonitor()
        // Инициализация MenuManager
        menuManager = MenuManager(parentViewController: self)
        // Настройка меню
        menuManager.setupCustomMenuIcon()
        menuManager.setupSideMenu()
    }
    
    // MARK: - Helper Methods
    /// Настраивает наблюдателя для завершения работы приложения
    private func setupAppTerminationObserver() {
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleAppTermination),
            name: UIApplication.willTerminateNotification,
            object: nil
        )
        print("[ConnectViewController] App termination observer added.")
    }
    // MARK: - UI Configuration

    /// Конфигурация всех UI-элементов
    private func configureUI() {
        setupIPLabel()
        setupSpeedLabel()
        setupIDLabel()
        addConcentricCircleView()
        setupStartButton()
        measureDownloadSpeed()
        updateButtonAppearance()
        updateIPLabelTranslation()
        setupCountryOptionsView()
    }

    
    private func updateUIForVPNState() {
        let translations = buttonTranslations[languageManager.currentLanguage] ?? buttonTranslations["en"]!
        connectLabel.text = isConnected ? translations.2 : translations.0
        navigationItem.title = isConnected ? "CONNECTED" : "DISCONNECTED"
    }

    /// Метод для перехода на экран входа
    private func navigateToLogin() {
        let loginVC = LoginViewController()
        loginVC.modalPresentationStyle = .fullScreen
        if let navigationController = self.navigationController {
            navigationController.setViewControllers([loginVC], animated: true)
        } else {
            present(loginVC, animated: true, completion: nil)
        }
    }
    
    
    // Функция для получения сохраненного имени пользователя
    private func fetchSavedUsername() -> String {
        return UserDefaults.standard.string(forKey: "username") ?? "Unknown"
    }


    // Сохранение имени пользователя при необходимости
    private func saveUsername(_ username: String) {
        UserDefaults.standard.set(username, forKey: "username")
        UserDefaults.standard.synchronize()
        print("[Info] Username saved to UserDefaults: \(username)")
    }

    // Обработка завершения работы приложения
    @objc private func handleAppTermination() {
        print("[App] Application is terminating. Saving VPN state and user info...")
        saveVPNState()
    }

    // Функция для сохранения состояния VPN
    private func saveVPNState() {
        print("[VPN] Saving VPN state...")
        
        // Пример состояния VPN
        let vpnState = "connected" // Или другое значение, представляющее текущее состояние VPN (например, "disconnected", "connecting")
        
        // Сохранение состояния VPN в UserDefaults
        UserDefaults.standard.set(vpnState, forKey: "vpnState")
        UserDefaults.standard.synchronize()
        print("[VPN] VPN state saved: \(vpnState)")
    }

    // Восстановление состояния VPN
    private func restoreVPNState() {
        if let savedState = UserDefaults.standard.value(forKey: "vpnState") {
            print("[VPN] Restoring VPN state: \(savedState)")
            // Восстановите состояние здесь
        } else {
            print("[VPN] No saved state found.")
        }
    }

    private func setupCountryOptionsView() {
        guard let languageManager = languageManager else {
            print("[Error] Failed to initialize CountryOptionsView due to missing LanguageManager.")
            return
        }

        let countryOptionsView = CountryOptionsView(
            languageManager: languageManager,
            onSelect: { [weak self] selectedCountry in
                guard let self = self else { return }
                self.selectedCountry = selectedCountry

                // Update flag based on selection
                if selectedCountry == "Netherlands" {
                    self.updateCountryFlag(for: "netherlands_flag")
                } else {
                    self.updateCountryFlag(for: nil)
                }

                print("Selected country: \(selectedCountry ?? "no data")")
            }
        )

        hostingController = UIHostingController(rootView: countryOptionsView)

        if let hostingController = hostingController {
            addChild(hostingController)
            hostingController.view.translatesAutoresizingMaskIntoConstraints = false
            hostingController.view.backgroundColor = .clear
            view.addSubview(hostingController.view)
            hostingController.didMove(toParent: self)

            NSLayoutConstraint.activate([
                hostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
                hostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
                hostingController.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20),
                hostingController.view.heightAnchor.constraint(equalToConstant: 150)
            ])
        }
    }

    deinit {
        // Remove observers to avoid memory leaks
        NotificationCenter.default.removeObserver(self, name: UIApplication.willTerminateNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
        print("[ConnectViewController] Observers removed.")
    }


    
    private func restoreSavedVPNState() {
        // Получаем сохраненное состояние
        let savedState = UserDefaults.standard.bool(forKey: "isConnected")
        
        // Если состояние изменилось, обновляем его
        if isConnected != savedState {
            isConnected = savedState
            updateButtonAppearance()
            print("[restoreSavedVPNState] VPN state restored to: \(isConnected)")
        } else {
            print("[restoreSavedVPNState] No change in VPN state: \(isConnected)")
        }

        // Дополнительная логика при восстановлении (если необходимо)
        if isConnected {
            // Можно, например, попытаться повторно подключиться
            print("[restoreSavedVPNState] VPN is active. Reconnecting...")
        } else {
            print("[restoreSavedVPNState] VPN is not active.")
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)

        // Останавливаем все таймеры
        connectionTimer?.invalidate()
        connectionTimer = nil
        connectionStartTime = nil
        animationTimer?.invalidate()
        animationTimer = nil
        UserDefaults.standard.set(isConnected, forKey: "isConnected")
        UserDefaults.standard.synchronize()
    }
    
    func rebuildCountryOptionsView() {
        // Удаляем старый хостинг-контроллер
        if let oldHostingController = hostingController {
            oldHostingController.view.removeFromSuperview()
            oldHostingController.removeFromParent()
        }

        // Создаем новый CountryOptionsView
        let countryOptionsView = CountryOptionsView(
            languageManager: languageManager, // Передаем LanguageManager
            onSelect: { [weak self] country in
                guard let self = self else { return }
                self.selectedCountry = country

                if country == "Netherlands" {
                    self.updateCountryFlag(for: "netherlands_flag")
                    self.updateStaticIP("89.110.86.151")
                } else {
                    self.updateCountryFlag(for: nil)
                    self.updateStaticIP("--.--.--.--")
                }
            }
        )
        // Создаем новый хостинг-контроллер
        let newHostingController = UIHostingController(rootView: countryOptionsView)
        newHostingController.view.translatesAutoresizingMaskIntoConstraints = false
        newHostingController.view.backgroundColor = UIColor.clear // Устанавливаем прозрачный фон

        // Добавляем новый контроллер
        addChild(newHostingController)
        view.addSubview(newHostingController.view)

        NSLayoutConstraint.activate([
            newHostingController.view.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            newHostingController.view.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            newHostingController.view.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: 20),
            newHostingController.view.heightAnchor.constraint(equalToConstant: 150)
        ])
        newHostingController.didMove(toParent: self)

        // Присваиваем новый контроллер
        hostingController = newHostingController
    }
    func updateIPLabelText(with ipAddress: String) {
        DispatchQueue.main.async { // Обновление UI должно быть на главном потоке
            self.ipLabel.text = String(format: NSLocalizedString("IP: %@", comment: "IP address format"), ipAddress)
        }
    }
    
    // MARK: Добавление кругов
        
    private func addConcentricCircleView() {
        // Определяем размеры для macOS, iPad и iPhone
        let concentricCircleSize: CGFloat
        let circleImageSize: CGFloat
        let circleCornerRadius: CGFloat
        let centerYOffset: CGFloat

        #if targetEnvironment(macCatalyst)
        // Настройки для macOS
        concentricCircleSize = 320
        circleImageSize = 240
        circleCornerRadius = 120
        centerYOffset = -120
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            // Настройки для iPad
            concentricCircleSize = 280
            circleImageSize = 220
            circleCornerRadius = 110
            centerYOffset = -110
        } else {
            // Настройки для iPhone
            concentricCircleSize = 240
            circleImageSize = 180
            circleCornerRadius = 90
            centerYOffset = -100
        }
        #endif

        // Создаем ConcentricCircleView и оборачиваем его в UIHostingController
        let concentricView = ConcentricCircleView()
        concentricCircleHostingController = UIHostingController(rootView: concentricView)

        guard let concentricCircleHostingController = concentricCircleHostingController else { return }

        // Добавляем хостинг-контроллер как дочерний
        addChild(concentricCircleHostingController)
        concentricCircleHostingController.view.translatesAutoresizingMaskIntoConstraints = false
        concentricCircleHostingController.view.backgroundColor = .clear
        view.addSubview(concentricCircleHostingController.view)
        concentricCircleHostingController.didMove(toParent: self)

        // Констрейнты для размещения круга
        NSLayoutConstraint.activate([
            concentricCircleHostingController.view.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            concentricCircleHostingController.view.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: centerYOffset),
            concentricCircleHostingController.view.widthAnchor.constraint(equalToConstant: concentricCircleSize),
            concentricCircleHostingController.view.heightAnchor.constraint(equalToConstant: concentricCircleSize)
        ])

        // Создаем UIImageView для изображения внутри круга
        let circleImageView = UIImageView()
        circleImageView.contentMode = .scaleAspectFill
        circleImageView.clipsToBounds = true
        circleImageView.layer.cornerRadius = circleCornerRadius // Радиус круга
        circleImageView.layer.masksToBounds = true
        circleImageView.isHidden = true // Скрываем изображение по умолчанию
        self.circleImageView = circleImageView // Сохраняем ссылку на ImageView
        view.addSubview(circleImageView)

        circleImageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            circleImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            circleImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: centerYOffset),
            circleImageView.widthAnchor.constraint(equalToConstant: circleImageSize), // Размер внутреннего круга
            circleImageView.heightAnchor.constraint(equalToConstant: circleImageSize)
        ])

        // Создаем маску для круга, чтобы изображение было круглым
        let maskLayer = CAShapeLayer()
        maskLayer.path = UIBezierPath(ovalIn: CGRect(x: 0, y: 0, width: circleImageSize, height: circleImageSize)).cgPath
        circleImageView.layer.mask = maskLayer
    }

    
    // MARK: Custom Button Setup
    private func setupStartButton() {
        let buttonWidth: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 250 : 190
        let buttonHeight: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 60 : 47
        let buttonFontSize: CGFloat = UIDevice.current.userInterfaceIdiom == .pad ? 20 : 17

        startButton = UIButton(type: .custom)
        startButton.backgroundColor = .clear
        startButton.translatesAutoresizingMaskIntoConstraints = false

        let customShapeLayer = CAShapeLayer()
        customShapeLayer.fillColor = UIColor(named: "button_con")?.cgColor ?? UIColor.black.cgColor
        customShapeLayer.strokeColor = UIColor.clear.cgColor
        startButton.layer.insertSublayer(customShapeLayer, at: 0)

        connectLabel = UILabel()
        connectLabel.text = "Connect"
        connectLabel.textColor = .white
        connectLabel.font = UIFont.systemFont(ofSize: buttonFontSize, weight: .semibold)
        connectLabel.textAlignment = .center
        connectLabel.translatesAutoresizingMaskIntoConstraints = false

        startButton.addSubview(connectLabel)
        NSLayoutConstraint.activate([
            connectLabel.centerXAnchor.constraint(equalTo: startButton.centerXAnchor),
            connectLabel.centerYAnchor.constraint(equalTo: startButton.centerYAnchor)
        ])

        startButton.addTarget(self, action: #selector(startButtonTouch), for: .touchUpInside)
        view.addSubview(startButton)

        NSLayoutConstraint.activate([
            startButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            startButton.topAnchor.constraint(equalTo: concentricCircleHostingController?.view.bottomAnchor ?? view.centerYAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 60 : 40), // Больше отступ сверху для iPad
            startButton.widthAnchor.constraint(equalToConstant: buttonWidth),
            startButton.heightAnchor.constraint(equalToConstant: buttonHeight)
        ])

        DispatchQueue.main.async {
            self.updateButtonShape(layer: customShapeLayer)
        }
    }


    private func updateButtonShape(layer: CAShapeLayer) {
        let buttonPath = createCustomButtonPath(bounds: startButton.bounds)
        layer.path = buttonPath.cgPath
    }

    private func createCustomButtonPath(bounds: CGRect) -> UIBezierPath {
        let buttonWidth = bounds.width
        let buttonHeight = bounds.height
        let cornerRadius: CGFloat = 16
        let triangleHeight: CGFloat = 8

        let path = UIBezierPath()
        path.move(to: CGPoint(x: cornerRadius, y: 0))
        path.addLine(to: CGPoint(x: buttonWidth - cornerRadius, y: 0))
        path.addArc(withCenter: CGPoint(x: buttonWidth - cornerRadius, y: cornerRadius),
                    radius: cornerRadius,
                    startAngle: CGFloat(-Double.pi / 2),
                    endAngle: 0,
                    clockwise: true)
        path.addLine(to: CGPoint(x: buttonWidth, y: buttonHeight - cornerRadius))
        path.addArc(withCenter: CGPoint(x: buttonWidth - cornerRadius, y: buttonHeight - cornerRadius),
                    radius: cornerRadius,
                    startAngle: 0,
                    endAngle: CGFloat(Double.pi / 2),
                    clockwise: true)
        path.addLine(to: CGPoint(x: cornerRadius, y: buttonHeight))
        path.addArc(withCenter: CGPoint(x: cornerRadius, y: buttonHeight - cornerRadius),
                    radius: cornerRadius,
                    startAngle: CGFloat(Double.pi / 2),
                    endAngle: CGFloat(Double.pi),
                    clockwise: true)
        path.addLine(to: CGPoint(x: 0, y: cornerRadius))
        path.addArc(withCenter: CGPoint(x: cornerRadius, y: cornerRadius),
                    radius: cornerRadius,
                    startAngle: CGFloat(Double.pi),
                    endAngle: CGFloat(-Double.pi / 2),
                    clockwise: true)
        path.addLine(to: CGPoint(x: buttonWidth / 2 + 8, y: 0))
        path.addLine(to: CGPoint(x: buttonWidth / 2, y: -triangleHeight))
        path.addLine(to: CGPoint(x: buttonWidth / 2 - 8, y: 0))
        path.close()
        return path
    }

    // MARK: Button Appearance
    private let buttonTranslations: [String: (String, String, String)] = [
        "en": ("Connect", "Connecting...", "Disconnect"),
        "zh": ("连接", "连接中...", "断开连接"),
        "ru": ("Подключиться", "Подключение...", "Отключить"),
        "ar": ("اتصل", "جاري الاتصال...", "قطع الاتصال")
    ]

    private func updateButtonAppearance() {
        DispatchQueue.main.async { // Обновление UI на главном потоке
            guard let shapeLayer = self.startButton.layer.sublayers?.first as? CAShapeLayer else { return }

            // Тексты кнопки
            let translations = self.buttonTranslations[LanguageManager.shared.currentLanguage] ?? self.buttonTranslations["en"]!

            // Обновляем текст и цвет кнопки
            if self.isConnected {
                self.connectLabel.text = translations.2 // "Disconnect"
                shapeLayer.fillColor = UIColor(named: "Color_dis")?.cgColor ?? UIColor.red.cgColor
            } else {
                self.connectLabel.text = translations.0 // "Connect"
                shapeLayer.fillColor = UIColor(named: "button_con")?.cgColor ?? UIColor.black.cgColor
            }

            print("[UI] Кнопка обновлена: \(self.connectLabel.text ?? "")")
            self.startButton.setNeedsLayout()
            self.startButton.layoutIfNeeded()
        }
    }
    
    private func updateButtonTranslation() {
        updateButtonAppearance() // Перестраивает кнопку с новым переводом
    }
    private func setupLanguageObserver() {
        NotificationCenter.default.addObserver(forName: .languageChanged, object: nil, queue: .main) { [weak self] _ in
            self?.updateButtonTranslation()
        }
    }

    private func setupIPLabel() {
        ipLabel = UILabel()
        
        // Настраиваем шрифт и другие параметры
        #if targetEnvironment(macCatalyst)
        ipLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular) // Увеличенный шрифт для macOS
        ipLabel.textColor = .white // Более светлый текст на macOS
        #else
        if UIDevice.current.userInterfaceIdiom == .pad {
            ipLabel.font = UIFont.systemFont(ofSize: 16, weight: .regular) // Увеличенный шрифт для iPad
            ipLabel.textColor = .white // Более мягкий текст для iPad
        } else {
            ipLabel.font = UIFont.systemFont(ofSize: 14, weight: .regular) // Обычный шрифт для iPhone
            ipLabel.textColor = .white
        }
        #endif
        
        ipLabel.textAlignment = .right
        ipLabel.numberOfLines = 1
        ipLabel.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(ipLabel)

        // Устанавливаем констрейнты
        NSLayoutConstraint.activate([
            ipLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: UIDevice.current.userInterfaceIdiom == .pad ? 12 : 8), // Увеличенный отступ для iPad
            ipLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16) // Унифицированный отступ справа
        ])

        updateIPLabelTranslation()
    }
    
    func updateIPLabelTranslation() {
        DispatchQueue.main.async {
            let selectedLanguage = UserDefaults.standard.string(forKey: "AppLanguage") ?? "en"
            let translations: [String: String] = [
                "en": "IP: 89.110.86.151",
                "zh": "IP地址: 89.110.86.151",
                "ru": "IP-адрес: 89.110.86.151",
                "ar": "الملكية الفكرية: 89.110.86.151"
            ]
            self.ipLabel.text = translations[selectedLanguage] ?? translations["en"]
            print("IP Label updated to: \(self.ipLabel.text ?? "N/A")")
        }
    }
    private func getUsernameFromIDLabel() -> String {
        guard let text = idLabel?.text else { return "default_username" }
        let components = text.split(separator: ":").map { $0.trimmingCharacters(in: .whitespaces) }
        return components.count > 1 ? components[1] : "default_username"
    }

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // Обновляем компоновку
        view.setNeedsLayout()
        view.layoutIfNeeded()
        
        // Отключаем жест свайпа назад
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        
        // Синхронизация видимости флага
        updateMenuState()
        print("[ViewDidAppear] circleImageView visibility set to \(isMenuVisible ? "hidden" : "visible").")
    }

    private func updateMenuState() {
        // Убедитесь, что обновление UI выполняется немедленно в основном потоке
        DispatchQueue.main.async {
            let shouldHideFlag = self.isMenuVisible
            self.circleImageView?.isHidden = shouldHideFlag
            print("[updateMenuState] circleImageView visibility synchronized with isMenuVisible = \(shouldHideFlag).")
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Включаем жест свайпа назад перед уходом с экрана
        navigationController?.interactivePopGestureRecognizer?.isEnabled = true
        
        // Скрываем флаг немедленно
        DispatchQueue.main.async {
            self.circleImageView?.isHidden = true
            print("[ViewWillDisappear] circleImageView hidden immediately.")
        }
    }

    private var connectionState: ConnectionState = .disconnected {
        didSet {
            updateButtonAppearance() // Обновляем интерфейс при изменении состояния
        }
    }
    
    private func setupNetworkMonitor() {
        networkMonitor = NWPathMonitor()
        let queue = DispatchQueue.global(qos: .background)
        networkMonitor?.start(queue: queue)

        networkMonitor?.pathUpdateHandler = { [weak self] path in
            DispatchQueue.main.async {
                if path.status == .satisfied {
                    print("[NetworkMonitor] Internet connection is available.")
                } else {
                    print("[NetworkMonitor] No internet connection.")
                    self?.isConnected = false
                    self?.updateButtonAppearance()
                }
            }
        }
    }

    @IBAction func startButtonTouch(_ sender: UIButton) {
        guard selectedCountry != nil else {
            print("[ConnectViewController] Country not selected.")
            return
        }

        if isConnected {
            // Отключение через единый метод
            disconnectVPN()
        } else {
            // Подключение
            startConnectingAnimation()
            navigationItem.title = "CONNECTING..."

            // Отправляем запросы для подключения
            interactor?.makeRequest(request: .didSelectProtocol(index: 1))
            interactor?.makeRequest(request: .startButtonTouch)

            // Завершаем процесс подключения через 5 секунд
            DispatchQueue.main.asyncAfter(deadline: .now() + 5) { [weak self] in
                guard let self = self else { return }
                self.stopConnectingAnimation()
                self.isConnected = true
                self.updateButtonAppearance()
                self.navigationItem.title = "CONNECTED"
                print("[ConnectViewController] VPN connected.")
            }
        }
        // Обновляем внешний вид кнопки
        updateButtonAppearance()
    }
    private func showNoInternetAlert() {
        let translations: [String: (String, String)] = [
            "en": ("No Internet", "Please check your internet connection and try again."),
            "zh": ("无网络连接", "请检查您的网络连接，然后重试。"),
            "ru": ("Нет Интернета", "Пожалуйста, проверьте подключение к Интернету и попробуйте снова."),
            "ar": ("لا يوجد اتصال بالإنترنت", "يرجى التحقق من اتصالك بالإنترنت والمحاولة مرة أخرى.")
        ]
        
        // Определяем текущий язык приложения
        let language = languageManager.currentLanguage
        let alertText = translations[language] ?? translations["en"]!
        
        let alert = UIAlertController(
            title: alertText.0, // Заголовок
            message: alertText.1, // Сообщение
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true, completion: nil)
    }

    @objc func handleTermination() {
        print("[ConnectViewController] Handling app termination.")
        // Устанавливаем флаг isConnected в false
        isConnected = false
        UserDefaults.standard.set(false, forKey: "isConnected")
        UserDefaults.standard.synchronize() // Синхронизируем изменения в UserDefault
        // Отключение VPN
        disconnectVPN()
        print("[ConnectViewController] Application terminated. isConnected set to false.")
    }

    func disconnectVPN() {
        isConnecting = false // Сбрасываем флаг подключения
        isConnected = false
        UserDefaults.standard.set(false, forKey: "isConnected")
        interactor?.makeRequest(request: .disconnect)
        stopConnectingAnimation()
        updateButtonAppearance()
        navigationItem.title = "DISCONNECTED"
        print("[ConnectViewController] VPN disconnected.")
    }


    private func startConnectingAnimation() {
        var dotCount = 0
        animationTimer?.invalidate()

        let translations: [String: String] = [
            "en": "Connecting",
            "zh": "连接中",
            "ru": "Подключение",
            "ar": "جارٍ الاتصال"
        ]

        let connectingText = translations[languageManager.currentLanguage] ?? "Connecting"

        animationTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            dotCount = (dotCount + 1) % 4
            self.connectLabel.text = connectingText + String(repeating: ".", count: dotCount)
        }
    }


    private func startDisconnectAnimation() {
        animationTimer?.invalidate() // Останавливаем предыдущую анимацию
        animationTimer = nil // Сбрасываем таймер

        // Переводы текста для кнопки "Disconnect"
        let translations: [String: String] = [
            "en": "Disconnect",
            "zh": "断开连接",
            "ru": "Отключить",
            "ar": "قطع الاتصال"
        ]

        // Устанавливаем текст на кнопку
        let disconnectText = translations[languageManager.currentLanguage] ?? "Disconnect"
        connectLabel.text = disconnectText
    }

    private func stopConnectingAnimation() {
        animationTimer?.invalidate() // Останавливаем анимацию
        animationTimer = nil // Сбрасываем таймер

        // Переводы текста для кнопки
        let translations: [String: String] = [
            "en": "Connect",
            "zh": "连接",
            "ru": "Подключить",
            "ar": "اتصال"
        ]

        // Получаем текст кнопки в зависимости от текущего языка
        let buttonText = translations[languageManager.currentLanguage] ?? "Connect"

        // Устанавливаем текст кнопки
        connectLabel.text = isConnected ? "Disconnect" : buttonText
    }

}
