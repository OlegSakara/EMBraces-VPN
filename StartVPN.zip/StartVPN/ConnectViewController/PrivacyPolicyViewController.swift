import UIKit

class PrivacyPolicyViewController: UIViewController {
    var onAccept: (() -> Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up background
        view.backgroundColor = UIColor(named: "MenuBackgroundColor") ?? .black
        
        // Add UI elements
        setupCloseButton()
        setupTitleLabel()
        setupContentTextView()
        setupAgreeButton()
    }
    
    private func setupTitleLabel() {
        let titleLabel = UILabel()
        titleLabel.text = "Privacy Policy"
        titleLabel.font = UIFont.systemFont(ofSize: 22, weight: .bold)
        titleLabel.textColor = .white
        titleLabel.textAlignment = .center
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(titleLabel)
        
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 25),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16)
        ])
    }

    private func setupContentTextView() {
        let textView = UITextView()
        textView.text = """
        Privacy Policy of LLC EMBREIS
                LLC EMBREIS values your privacy and is committed to protecting your personal information. This privacy policy explains how we process and safeguard data in the EMBraces VPN application, as well as our compliance with laws and Apple App Store requirements.

                1. Introduction
                By using the EMBraces VPN application, you agree to the terms of this privacy policy. If you do not agree, please do not use our application.

                2. Collected Data
                We do not collect or store personal information such as names, addresses, browsing history, or connection logs.

                For connection purposes:
                We use the OpenVPN protocol with AES-128 encryption, ensuring a high level of internet traffic protection.

                The VPN configuration file is retrieved from a secure API server where it is stored with modern protection methods.

                Account data:
                Only a username is required to use the application.

                Passwords are randomly generated to ensure user anonymity and are securely stored using KeychainHelper.

                3. Purpose
                The EMBraces VPN application is designed to provide secure and encrypted connections. We aim to protect your online activity from interception.

                The application is not intended to bypass restrictions or violate laws.

                Its primary purpose is to ensure security and privacy online.

                4. Legal Compliance
                We comply with the laws and regulations of all jurisdictions where the application operates.

                The EMBraces VPN application is not available in countries where VPN use is prohibited by law.

                We make every effort to adhere to local laws and regulations.

                5. Storage and Protection
                All sensitive data, including configuration files, certificates, and passwords, is stored encrypted on the user’s device.

                Configuration files are retrieved only via a secure API server protected by modern encryption protocols and restricted access.

                We use modern encryption standards, such as AES-128, to protect data.

                6. Security
                We take all necessary measures to safeguard your information:

                KeychainHelper is used to securely store sensitive data, such as passwords and certificates, on your device.

                All data processed by the EMBraces VPN application is securely encrypted, preventing interception or unauthorized access.

                7. Terms of Use
                EMBraces VPN is intended solely to secure internet connections and protect user privacy.

                The application does not log, track, or monitor user activities.

                Our service is focused exclusively on user security and privacy.

                8. Compliance with Apple App Store Requirements
                We comply with all Apple App Store Guidelines, including:

                Transparency: Clearly stating how data is used and protected.

                Access Restrictions: The application is only available in countries where VPN use is legally permitted.

                Data Minimization: Collecting minimal data to ensure user privacy.

                The EMBraces VPN application complies with sections 5.1.1 (Privacy) and 5.1.2 (Data Use and Sharing) of the Apple App Store guidelines. We ensure that no user data is used without their knowledge and consent.

                9. Contact Information
                If you have any questions, suggestions, or feedback regarding this privacy policy, you can contact us at: embreisltd@gmail.com

                LLC EMBREIS ensures that the EMBraces VPN application provides a secure and protected internet connection, complies with legal requirements, and respects the privacy of your data.
        """
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.textColor = .white
        textView.backgroundColor = .clear
        textView.isEditable = false
        textView.isScrollEnabled = true
        textView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(textView)
        
        NSLayoutConstraint.activate([
            textView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 60),
            textView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            textView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            textView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -100)
        ])
    }
    
    private func setupAgreeButton() {
        let agreeButton = UIButton(type: .system)
        agreeButton.setTitle("Agree and Continue", for: .normal)
        agreeButton.setTitleColor(.white, for: .normal)
        agreeButton.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        agreeButton.backgroundColor = UIColor(red: 238/255, green: 135/255, blue: 50/255, alpha: 1.0) // #EE8732
        agreeButton.layer.cornerRadius = 8
        agreeButton.translatesAutoresizingMaskIntoConstraints = false

        agreeButton.addTarget(self, action: #selector(handleAgreeButtonTapped), for: .touchUpInside)

        view.addSubview(agreeButton)

        NSLayoutConstraint.activate([
            agreeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            agreeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            agreeButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            agreeButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    private func setupCloseButton() {
        let closeButton = UIButton(type: .system)
        closeButton.setImage(UIImage(systemName: "xmark"), for: .normal)
        closeButton.tintColor = .white
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        
        closeButton.addTarget(self, action: #selector(handleCloseButtonTapped), for: .touchUpInside)
        
        view.addSubview(closeButton)
        
        NSLayoutConstraint.activate([
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            closeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            closeButton.widthAnchor.constraint(equalToConstant: 30),
            closeButton.heightAnchor.constraint(equalToConstant: 30)
        ])
    }
    
    @objc private func handleAgreeButtonTapped() {
        UserDefaults.standard.set(true, forKey: "hasAgreedToPrivacyPolicy")
        UserDefaults.standard.synchronize()
        
        let isLoggedIn = UserDefaults.standard.bool(forKey: "isLoggedIn")
        let rootViewController: UIViewController
        
        if isLoggedIn {
            rootViewController = UINavigationController(rootViewController: ConnectViewController())
        } else {
            rootViewController = UINavigationController(rootViewController: AccountViewController())
        }

        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let window = windowScene.windows.first {
            window.rootViewController = rootViewController
            window.makeKeyAndVisible()
        } else {
            print("[PrivacyPolicyViewController] Failed to update rootViewController: No active window found.")
        }
    }
    
    @objc private func handleCloseButtonTapped() {
        print("[PrivacyPolicyViewController] User declined privacy policy.")
        exit(0)
    }
}
