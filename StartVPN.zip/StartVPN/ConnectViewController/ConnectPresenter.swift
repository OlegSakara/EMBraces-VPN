import UIKit

protocol ConnectPresentationLogic {
    func presentData(response: Connect.Model.Response.ResponseType)
}

class ConnectPresenter: ConnectPresentationLogic {
    weak var viewController: ConnectDisplayLogic?

    func presentData(response: Connect.Model.Response.ResponseType) {
        switch response {
        case .presentCountries:
            viewController?.displayData(viewModel: .displayCountries)

        case .presentCountry(let country):
            let viewModel = CountriesViewModel.Cell(country: country)
            viewController?.displayData(viewModel: .displayCountry(viewModel: viewModel))

        case .presentError(let title, let message):
            viewController?.displayData(viewModel: .displayErrorAlert(title: title, message: message))

        case .presentPasswordAlert:
            viewController?.displayData(viewModel: .displayPasswordAlert)

        case .presentStatusConnecting:
            handleStatusConnecting()

        case .presentStatusConnected:
            handleStatusConnected()

        case .presentStatusDisconnected:
            handleStatusDisconnected()

        case .presentTimer(let timer):
            viewController?.displayData(viewModel: .displayNavigationTitle(title: "CONNECTED \(timer)"))

        case .presentTrafficStats(let upload, let download):
            viewController?.displayData(viewModel: .displayTrafficStats(upload: upload, download: download))

        case .presentMap(let index):
            handleMapPresentation(index: index)
        }
    }

    // MARK: - Private Helper Methods

    private func handleStatusConnecting() {
        viewController?.displayData(viewModel: .displayNavigationTitle(title: "CONNECTING"))
        viewController?.displayData(viewModel: .displayPulsate(isEnable: true))
        viewController?.displayData(viewModel: .displayProtocolSegmentedControl(isEnable: false))
        
        if let image = UIImage(named: "Connect.png") {
            viewController?.displayData(viewModel: .displayStartButton(image: image))
        }
    }

    private func handleStatusConnected() {
        viewController?.displayData(viewModel: .displayPulsate(isEnable: false))
        viewController?.displayData(viewModel: .displayTrafficStackView(isEnable: true))
        
        if let image = UIImage(named: "Off.png") {
            viewController?.displayData(viewModel: .displayStartButton(image: image))
        }
    }

    private func handleStatusDisconnected() {
        viewController?.displayData(viewModel: .displayNavigationTitle(title: "DISCONNECTED"))
        viewController?.displayData(viewModel: .displayPulsate(isEnable: true))
        viewController?.displayData(viewModel: .displayTrafficStackView(isEnable: false))
        viewController?.displayData(viewModel: .displayProtocolSegmentedControl(isEnable: true))
        
        if let image = UIImage(named: "On.png") {
            viewController?.displayData(viewModel: .displayStartButton(image: image))
        }
    }

    private func handleMapPresentation(index: Int?) {
        guard let image = getMapImage(from: index) else { return }
        let transform = getMapTransform(from: index)
        viewController?.displayData(viewModel: .displayMap(image: image, transform: transform))
    }

    private func getMapImage(from index: Int?) -> UIImage? {
        guard let index = index, index > 0 else {
            return UIImage(named: "map")
        }
        return UIImage(named: "map_\(index)")
    }

    private func getMapTransform(from index: Int?) -> CGAffineTransform {
        switch index {
        case 1, 2:
            return CGAffineTransform(scaleX: 2, y: 2).concatenating(
                CGAffineTransform(translationX: 200, y: 80)
            )
        case 3, 4, 5:
            return CGAffineTransform(scaleX: 6, y: 6).concatenating(
                CGAffineTransform(translationX: 0, y: 150)
            )
        default:
            return .identity
        }
    }
}
