import SwiftUI

struct CustomMenuIcon: View {
    var body: some View {
        VStack(spacing: spacing) { // Расстояние между линиями
            Capsule()
                .frame(width: topLineWidth, height: lineHeight) // Верхняя линия
                .foregroundColor(Color.gray.opacity(0.9)) // Цвет линии
            
            Capsule()
                .frame(width: middleLineWidth, height: lineHeight) // Средняя линия
                .foregroundColor(Color.gray.opacity(0.9)) // Цвет линии
            
            Capsule()
                .frame(width: bottomLineWidth, height: lineHeight) // Нижняя линия
                .foregroundColor(Color.gray.opacity(0.9)) // Цвет линии
        }
        .frame(width: menuIconWidth, height: menuIconHeight) // Общий размер кнопки
        .contentShape(Rectangle()) // Увеличиваем область клика
    }

    // MARK: - Размеры для iOS и macOS
    private var topLineWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 40 // Ширина верхней линии для macOS
        #else
        return 32 // Ширина верхней линии для iOS
        #endif
    }
    
    private var middleLineWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 32 // Ширина средней линии для macOS
        #else
        return 24 // Ширина средней линии для iOS
        #endif
    }
    
    private var bottomLineWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 40 // Ширина нижней линии для macOS
        #else
        return 32 // Ширина нижней линии для iOS
        #endif
    }
    
    private var lineHeight: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 5 // Толщина линии для macOS
        #else
        return 4 // Толщина линии для iOS
        #endif
    }
    
    private var spacing: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 8 // Расстояние между линиями для macOS
        #else
        return 6 // Расстояние между линиями для iOS
        #endif
    }
    
    private var menuIconWidth: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 70 // Общая ширина кнопки для macOS
        #else
        return 50 // Общая ширина кнопки для iOS
        #endif
    }
    
    private var menuIconHeight: CGFloat {
        #if targetEnvironment(macCatalyst)
        return 70 // Общая высота кнопки для macOS
        #else
        return 50 // Общая высота кнопки для iOS
        #endif
    }
}

struct CustomMenuIcon_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            CustomMenuIcon()
                .preferredColorScheme(.dark) // Темный режим
                .previewLayout(.sizeThatFits)
            
            CustomMenuIcon()
                .preferredColorScheme(.light) // Светлый режим
                .previewLayout(.sizeThatFits)
        }
        .padding()
    }
}
